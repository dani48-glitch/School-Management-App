"""First-run seeding.

* The first admin account is always created. Its password comes from the
  ``ADMIN_PASSWORD`` secret/environment variable.
* In demo mode (default) a complete sample school is generated as well, with
  one demo teacher and one demo student login.
"""
from __future__ import annotations

import random
from datetime import date, timedelta
from typing import Optional

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from database.models import (
    Announcement,
    Attendance,
    ClassSubject,
    Exam,
    FeePayment,
    FeeStructure,
    Result,
    SchoolClass,
    Student,
    Subject,
    Teacher,
    TimetableEntry,
    User,
    utcnow,
)
from database.session import session_scope
from services._common import new_receipt_no
from utils.clock import today
from utils.config import ADMIN_PASSWORD, ADMIN_USERNAME, ATTENDANCE_STATUSES
from utils.security import hash_password, validate_password_strength

DEMO_ADMIN_PASSWORD = "Admin@123"
DEMO_ACCOUNTS = [
    ("Teacher", "teacher", "Teacher@123"),
    ("Student / Parent", "student", "Student@123"),
]

CLASSES = [("Grade 6", "A"), ("Grade 6", "B"), ("Grade 7", "A"), ("Grade 8", "A")]
SUBJECTS = [
    ("Mathematics", "MATH"),
    ("English", "ENG"),
    ("Science", "SCI"),
    ("Social Studies", "SST"),
    ("Computer Science", "CS"),
    ("Urdu", "URD"),
]
TEACHERS = [
    ("Sara Ahmed", "sara.ahmed@example.com", "0300-1111111", "M.Sc. Mathematics"),
    ("Imran Siddiqui", "imran.siddiqui@example.com", "0300-2222222", "M.A. English"),
    ("Nadia Hussain", "nadia.hussain@example.com", "0300-3333333", "M.Sc. Physics"),
    ("Kamran Ali", "kamran.ali@example.com", "0300-4444444", "M.A. History"),
    ("Farah Naz", "farah.naz@example.com", "0300-5555555", "BS Computer Science"),
    ("Tariq Mehmood", "tariq.mehmood@example.com", "0300-6666666", "M.A. Urdu"),
]
STUDENT_NAMES = [
    "Ayesha Khan", "Ali Raza", "Fatima Noor", "Hassan Ahmed", "Zainab Ali", "Usman Tariq",
    "Maryam Siddiqui", "Bilal Hussain", "Hira Malik", "Omar Farooq", "Sana Iqbal",
    "Hamza Sheikh", "Areeba Shah", "Daniyal Qureshi", "Laiba Anwar", "Saad Mirza",
    "Noor Fatima", "Ibrahim Baig", "Mahnoor Javed", "Faizan Ahmed", "Amna Rehman",
    "Taha Butt", "Iqra Aslam", "Rayyan Chaudhry",
]
FATHER_NAMES = ["Tariq", "Naveed", "Asif", "Rashid", "Shahid", "Javed", "Khalid", "Nasir"]


def seed_database(demo: bool) -> None:
    """Create the admin user (and demo data) if the database has no users yet."""
    with session_scope() as session:
        if session.scalar(select(func.count(User.id))):
            return

        admin_password: Optional[str] = (
            str(ADMIN_PASSWORD) if ADMIN_PASSWORD else (DEMO_ADMIN_PASSWORD if demo else None)
        )
        if not admin_password:
            raise RuntimeError(
                "ADMIN_PASSWORD is not set. Add it to .streamlit/secrets.toml (or the "
                "Streamlit Cloud Secrets box) or set the environment variable."
            )
        problem = validate_password_strength(admin_password)
        if problem:
            raise RuntimeError(f"ADMIN_PASSWORD is not acceptable: {problem}")

        session.add(
            User(
                username=ADMIN_USERNAME.strip().lower(),
                password_hash=hash_password(admin_password),
                role="admin",
                full_name="School Administrator",
            )
        )
        if demo:
            _seed_demo_data(session)


def _seed_demo_data(session: Session) -> None:
    rng = random.Random(2026)  # deterministic demo data
    current = today()

    # --- classes, subjects, teachers --------------------------------------
    classes = [SchoolClass(name=name, section=section) for name, section in CLASSES]
    subjects = [Subject(name=name, code=code) for name, code in SUBJECTS]
    teachers = [
        Teacher(
            name=name,
            email=email,
            phone=phone,
            qualification=qualification,
            joined_on=date(2017 + index, 8, 1),
        )
        for index, (name, email, phone, qualification) in enumerate(TEACHERS)
    ]
    session.add_all(classes + subjects + teachers)
    session.flush()

    # Every class studies every subject; teacher i owns subject i.
    for school_class in classes:
        for subject, teacher in zip(subjects, teachers):
            session.add(
                ClassSubject(
                    class_id=school_class.id, subject_id=subject.id, teacher_id=teacher.id
                )
            )

    # --- students ----------------------------------------------------------
    students: list[Student] = []
    for index, full_name in enumerate(STUDENT_NAMES):
        school_class = classes[index % len(classes)]
        grade = int(school_class.name.split()[-1])
        surname = full_name.split()[-1]
        students.append(
            Student(
                roll_no=str(index // len(classes) + 1),
                name=full_name,
                class_id=school_class.id,
                dob=date(current.year - grade - 5, rng.randint(1, 12), rng.randint(1, 28)),
                guardian_name=f"{FATHER_NAMES[index % len(FATHER_NAMES)]} {surname}",
                phone=f"0300-{1000000 + index * 7919:07d}",
                address=f"House {12 + index * 3}, Street {1 + index % 9}, Sample Town",
            )
        )
    session.add_all(students)
    session.flush()

    # --- demo logins ---------------------------------------------------------
    (teacher_label, teacher_user, teacher_pw), (_, student_user, student_pw) = DEMO_ACCOUNTS
    session.add(
        User(
            username=teacher_user,
            password_hash=hash_password(teacher_pw),
            role="teacher",
            full_name=teachers[0].name,
            teacher_id=teachers[0].id,
        )
    )
    session.add(
        User(
            username=student_user,
            password_hash=hash_password(student_pw),
            role="student",
            full_name=students[0].name,
            student_id=students[0].id,
        )
    )

    # --- attendance: last 45 days, weekdays only -------------------------------
    school_days = [
        current - timedelta(days=offset)
        for offset in range(45)
        if (current - timedelta(days=offset)).weekday() < 5
    ]
    for student in students:
        for day in school_days:
            status = rng.choices(ATTENDANCE_STATUSES, weights=[88, 6, 4, 2])[0]
            session.add(Attendance(student_id=student.id, att_date=day, status=status))

    # --- exams and results ---------------------------------------------------
    exams = [
        Exam(name="Mid-Term Exam", exam_date=current - timedelta(days=21), max_marks=100),
        Exam(name="Unit Test 1", exam_date=current - timedelta(days=60), max_marks=50),
    ]
    session.add_all(exams)
    session.flush()
    ability = {student.id: rng.gauss(0.72, 0.12) for student in students}
    for exam in exams:
        for student in students:
            for subject in subjects:
                fraction = min(max(rng.gauss(ability[student.id], 0.08), 0.25), 1.0)
                session.add(
                    Result(
                        exam_id=exam.id,
                        student_id=student.id,
                        subject_id=subject.id,
                        marks=float(round(fraction * exam.max_marks)),
                    )
                )

    # --- fees -------------------------------------------------------------------
    class_totals: dict[int, int] = {}
    for school_class in classes:
        grade = int(school_class.name.split()[-1])
        structure = [
            ("Tuition Fee", 18000 + 2000 * (grade - 6)),
            ("Exam Fee", 2500),
            ("Annual Charges", 5000),
        ]
        class_totals[school_class.id] = sum(amount for _, amount in structure)
        for fee_type, amount in structure:
            session.add(FeeStructure(class_id=school_class.id, fee_type=fee_type, amount=amount))

    for student in students:
        total = class_totals[student.class_id]
        plan = rng.choices(["full", "partial", "none"], weights=[45, 35, 20])[0]
        if plan == "none":
            continue
        amount = total if plan == "full" else int(round(total * rng.choice([0.3, 0.5, 0.6]), -2))
        paid_on = current - timedelta(days=rng.randint(1, 30))
        session.add(
            FeePayment(
                receipt_no=new_receipt_no(paid_on),
                student_id=student.id,
                amount=amount,
                paid_on=paid_on,
                method=rng.choice(["Cash", "Bank Transfer", "Online"]),
                note="Demo payment",
                received_by="School Administrator",
            )
        )

    # --- timetable (Mon-Fri, 6 periods, rotating subjects, no teacher clashes) ----
    for class_index, school_class in enumerate(classes):
        for day in range(5):
            for period in range(1, 7):
                subject_index = (day + period + class_index) % len(subjects)
                session.add(
                    TimetableEntry(
                        class_id=school_class.id,
                        day=day,
                        period=period,
                        subject_id=subjects[subject_index].id,
                        teacher_id=teachers[subject_index].id,
                        room=f"R-{10 + class_index}",
                    )
                )

    # --- announcements -------------------------------------------------------------
    session.add_all(
        [
            Announcement(
                title="Welcome to the new term",
                body="We wish all students and staff a productive and joyful term. "
                "Please check your timetable and report any clashes to the office.",
                posted_by="School Administrator",
                created_at=utcnow() - timedelta(days=10),
            ),
            Announcement(
                title="Parent-teacher meeting",
                body="The parent-teacher meeting will be held on the first Saturday of next "
                "month from 9:00 AM to 1:00 PM. Report cards will be shared at the meeting.",
                posted_by="School Administrator",
                created_at=utcnow() - timedelta(days=4),
            ),
            Announcement(
                title="Fee reminder",
                body="Parents are requested to clear any pending dues before the end of the "
                "month. Receipts can be downloaded from the Fees page.",
                posted_by="School Administrator",
                created_at=utcnow() - timedelta(days=1),
            ),
        ]
    )
