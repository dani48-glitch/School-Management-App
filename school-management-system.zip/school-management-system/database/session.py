"""Engine and session handling.

SQLite is the default (zero setup). Point ``DATABASE_URL`` at PostgreSQL, for
example ``postgresql+psycopg2://user:pass@host/dbname``, to switch databases
without touching any other code.
"""
from __future__ import annotations

from contextlib import contextmanager
from typing import Iterator, Optional

from sqlalchemy import Engine, create_engine, event
from sqlalchemy.orm import Session, sessionmaker

from utils.config import DATABASE_URL

_engine: Optional[Engine] = None
_session_factory: Optional[sessionmaker] = None


def _normalise_url(url: str) -> str:
    """Heroku/Supabase style ``postgres://`` URLs must be ``postgresql://`` for SQLAlchemy."""
    if url.startswith("postgres://"):
        return "postgresql://" + url[len("postgres://"):]
    return url


def get_engine() -> Engine:
    """Create the engine lazily and reuse it for the whole process."""
    global _engine, _session_factory
    if _engine is None:
        url = _normalise_url(DATABASE_URL)
        if url.startswith("sqlite"):
            engine = create_engine(
                url, connect_args={"check_same_thread": False, "timeout": 30}
            )

            @event.listens_for(engine, "connect")
            def _enable_sqlite_foreign_keys(dbapi_connection, _record) -> None:
                cursor = dbapi_connection.cursor()
                cursor.execute("PRAGMA foreign_keys=ON")
                cursor.close()
        else:
            engine = create_engine(url, pool_pre_ping=True)
        _engine = engine
        _session_factory = sessionmaker(bind=engine, expire_on_commit=False)
    return _engine


@contextmanager
def session_scope() -> Iterator[Session]:
    """Transactional scope: commit on success, roll back on any error."""
    get_engine()
    assert _session_factory is not None
    session = _session_factory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def init_db(demo: Optional[bool] = None) -> None:
    """Create all tables and seed the first admin (plus demo data when ``demo``)."""
    from database import models
    from database.seed import seed_database
    from utils.config import DEMO_MODE

    models.Base.metadata.create_all(get_engine())
    seed_database(DEMO_MODE if demo is None else demo)


def reset_db(demo: Optional[bool] = None) -> None:
    """Drop every table and rebuild from scratch. DESTROYS ALL DATA."""
    from database import models

    models.Base.metadata.drop_all(get_engine())
    init_db(demo)
