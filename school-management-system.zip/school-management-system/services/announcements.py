"""Notice board."""
from __future__ import annotations

from typing import Optional

from sqlalchemy import select

from database.models import Announcement
from database.session import session_scope
from utils.validators import ValidationError, require_text


def list_announcements(limit: Optional[int] = None) -> list[dict]:
    """Newest first."""
    stmt = select(Announcement).order_by(Announcement.created_at.desc(), Announcement.id.desc())
    if limit:
        stmt = stmt.limit(limit)
    with session_scope() as session:
        return [
            {
                "id": item.id,
                "title": item.title,
                "body": item.body,
                "posted_by": item.posted_by,
                "created_at": item.created_at,
            }
            for item in session.scalars(stmt)
        ]


def add_announcement(title: str, body: str, posted_by: str) -> None:
    title = require_text(title, "Title", 150)
    body = (body or "").strip()
    if not body:
        raise ValidationError("Message is required.")
    if len(body) > 5000:
        raise ValidationError("Message must be at most 5000 characters.")
    with session_scope() as session:
        session.add(Announcement(title=title, body=body, posted_by=posted_by))


def delete_announcement(announcement_id: int) -> None:
    with session_scope() as session:
        item = session.get(Announcement, announcement_id)
        if item is None:
            raise ValidationError("Announcement not found.")
        session.delete(item)
