"""Daily attendance, monthly reports and per-student summaries.

Attendance percentage = (Present + Late) / all marked days x 100.
"""
from __future__ import annotations

import calendar
from datetime import date
from typing import Any, Optional

import pandas as pd
from sqlalchemy import func, select

from database.models import Attendance, Student
from database.session import session_scope
from utils.clock import today
from utils.config import ATTENDANCE_STATUSES
from utils.validators import ValidationError, coerce_date

_SYMBOLS = {"Present": "P", "Absent": "A", "Late": "L", "Leave": "LV"}


def percentage(present: int, late: int, marked: int) -> Optional[float]:
    """Attendance percentage, or ``None`` when nothing has been marked."""
    if not marked:
        return None
    return round((present + late) / marked * 100, 1)


def _class_students(session, class_id: int) -> list[tuple[int, str, str]]:
    rows = session.execute(
        select(Student.id, Student.roll_no, Student.name)
        .where(Student.class_id == class_id)
        .order_by(func.length(Student.roll_no), Student.roll_no)
    ).all()
    return [(row[0], row[1], row[2]) for row in rows]


def attendance_sheet(class_id: int, att_date: date) -> tuple[pd.DataFrame, bool]:
    """Roster for a class/date. Unmarked students default to Present.

    Returns ``(sheet, already_marked)`` where ``sheet`` has the columns
    ``student_id, roll_no, name, status``.
    """
    with session_scope() as session:
        students = _class_students(session, class_id)
        existing = dict(
            session.execute(
                select(Attendance.student_id, Attendance.status).where(
                    Attendance.att_date == att_date,
                    Attendance.student_id.in_([s[0] for s in students]),
                )
            ).all()
        )
    rows = [(sid, roll, name, existing.get(sid, "Present")) for sid, roll, name in students]
    sheet = pd.DataFrame(rows, columns=["student_id", "roll_no", "name", "status"])
    return sheet, bool(existing)


def save_attendance(class_id: int, att_date: Any, statuses: dict[int, str]) -> int:
    """Insert or update attendance for a class on one date. Returns rows saved."""
    day = coerce_date(att_date, "Date")
    if day is None or day > today():
        raise ValidationError("Attendance cannot be marked for a future date.")
    for status in statuses.values():
        if status not in ATTENDANCE_STATUSES:
            raise ValidationError(f"Invalid attendance status: {status!r}.")

    with session_scope() as session:
        valid_ids = [sid for sid, _, _ in _class_students(session, class_id)]
        existing = {
            record.student_id: record
            for record in session.scalars(
                select(Attendance).where(
                    Attendance.att_date == day, Attendance.student_id.in_(valid_ids)
                )
            )
        }
        saved = 0
        for student_id, status in statuses.items():
            if student_id not in valid_ids:
                continue  # ignore ids that are not in this class
            record = existing.get(student_id)
            if record is None:
                session.add(Attendance(student_id=student_id, att_date=day, status=status))
            else:
                record.status = status
            saved += 1
    return saved


def monthly_report(class_id: int, year: int, month: int) -> pd.DataFrame:
    """Per-student counts and attendance % for one month."""
    first = date(year, month, 1)
    last = date(year, month, calendar.monthrange(year, month)[1])
    with session_scope() as session:
        students = _class_students(session, class_id)
        counts = {
            (row[0], row[1]): row[2]
            for row in session.execute(
                select(Attendance.student_id, Attendance.status, func.count())
                .where(
                    Attendance.att_date.between(first, last),
                    Attendance.student_id.in_([s[0] for s in students]),
                )
                .group_by(Attendance.student_id, Attendance.status)
            ).all()
        }
    rows = []
    for sid, roll, name in students:
        present, absent, late, leave = (counts.get((sid, s), 0) for s in ATTENDANCE_STATUSES)
        marked = present + absent + late + leave
        rows.append((roll, name, present, absent, late, leave, marked,
                     percentage(present, late, marked)))
    return pd.DataFrame(
        rows,
        columns=["roll_no", "name", "present", "absent", "late", "leave", "marked_days",
                 "attendance_pct"],
    )


def monthly_matrix(class_id: int, year: int, month: int) -> pd.DataFrame:
    """Day-by-day grid (P / A / L / LV) for the days that have any record."""
    first = date(year, month, 1)
    last = date(year, month, calendar.monthrange(year, month)[1])
    with session_scope() as session:
        students = _class_students(session, class_id)
        records = session.execute(
            select(Attendance.student_id, Attendance.att_date, Attendance.status).where(
                Attendance.att_date.between(first, last),
                Attendance.student_id.in_([s[0] for s in students]),
            )
        ).all()
    days = sorted({record[1].day for record in records})
    lookup = {(record[0], record[1].day): _SYMBOLS.get(record[2], "?") for record in records}
    rows = []
    for sid, roll, name in students:
        rows.append([roll, name] + [lookup.get((sid, day), "") for day in days])
    return pd.DataFrame(rows, columns=["roll_no", "name"] + [str(day) for day in days])


def student_history(
    student_id: int, start: Optional[date] = None, end: Optional[date] = None
) -> pd.DataFrame:
    """Attendance records for one student, newest first."""
    stmt = select(Attendance.att_date, Attendance.status).where(
        Attendance.student_id == student_id
    )
    if start is not None:
        stmt = stmt.where(Attendance.att_date >= start)
    if end is not None:
        stmt = stmt.where(Attendance.att_date <= end)
    stmt = stmt.order_by(Attendance.att_date.desc())
    with session_scope() as session:
        rows = session.execute(stmt).all()
    return pd.DataFrame([(r[0], r[1]) for r in rows], columns=["date", "status"])


def student_summary(
    student_id: int, start: Optional[date] = None, end: Optional[date] = None
) -> dict:
    """Counts per status plus the attendance percentage."""
    history = student_history(student_id, start, end)
    counts = {status: int((history["status"] == status).sum()) for status in ATTENDANCE_STATUSES}
    marked = sum(counts.values())
    return {
        "counts": counts,
        "marked": marked,
        "percentage": percentage(counts["Present"], counts["Late"], marked),
    }
