"""Classes, subjects and the class-subject-teacher assignments."""
from __future__ import annotations

from typing import Optional

import pandas as pd
from sqlalchemy import func, select

from database.models import ClassSubject, SchoolClass, Student, Subject, Teacher
from database.session import session_scope
from services._common import class_label, integrity_guard, rows_to_df
from utils.validators import ValidationError, optional_text, require_text


# --------------------------------------------------------------------------
# Classes
# --------------------------------------------------------------------------
def class_options() -> list[tuple[int, str]]:
    stmt = select(SchoolClass.id, SchoolClass.name, SchoolClass.section).order_by(
        SchoolClass.name, SchoolClass.section
    )
    with session_scope() as session:
        rows = session.execute(stmt).all()
    return [(row[0], class_label(row[1], row[2])) for row in rows]


def list_classes() -> pd.DataFrame:
    with session_scope() as session:
        counts = dict(
            session.execute(
                select(Student.class_id, func.count(Student.id)).group_by(Student.class_id)
            ).all()
        )
        rows = session.execute(
            select(SchoolClass.id, SchoolClass.name, SchoolClass.section).order_by(
                SchoolClass.name, SchoolClass.section
            )
        ).all()
    data = [(row[0], row[1], row[2], counts.get(row[0], 0)) for row in rows]
    return pd.DataFrame(data, columns=["id", "name", "section", "students"])


def add_class(name: str, section: str) -> None:
    name = require_text(name, "Class name", 50)
    section = require_text(section, "Section", 10).upper()
    with integrity_guard(f"{class_label(name, section)} already exists."), session_scope() as s:
        s.add(SchoolClass(name=name, section=section))


def delete_class(class_id: int) -> None:
    with integrity_guard("This class still has students. Move or delete them first."):
        with session_scope() as session:
            school_class = session.get(SchoolClass, class_id)
            if school_class is None:
                raise ValidationError("Class not found.")
            session.delete(school_class)


# --------------------------------------------------------------------------
# Subjects
# --------------------------------------------------------------------------
def subject_options() -> list[tuple[int, str]]:
    with session_scope() as session:
        rows = session.execute(select(Subject.id, Subject.name).order_by(Subject.name)).all()
    return [(row[0], row[1]) for row in rows]


def list_subjects() -> pd.DataFrame:
    with session_scope() as session:
        rows = session.execute(
            select(Subject.id, Subject.name, Subject.code).order_by(Subject.name)
        ).all()
    return rows_to_df(rows, ["id", "name", "code"])


def add_subject(name: str, code: Optional[str]) -> None:
    name = require_text(name, "Subject name", 80)
    code_value = optional_text(code, "Subject code", 20)
    if code_value:
        code_value = code_value.upper()
    with integrity_guard("A subject with this name or code already exists."), session_scope() as s:
        s.add(Subject(name=name, code=code_value))


def delete_subject(subject_id: int) -> None:
    with session_scope() as session:
        subject = session.get(Subject, subject_id)
        if subject is None:
            raise ValidationError("Subject not found.")
        session.delete(subject)  # assignments, timetable slots and results cascade


# --------------------------------------------------------------------------
# Class <-> subject <-> teacher assignments
# --------------------------------------------------------------------------
def class_subject_table(
    class_id: Optional[int] = None, teacher_id: Optional[int] = None
) -> pd.DataFrame:
    stmt = (
        select(
            ClassSubject.id,
            ClassSubject.class_id,
            SchoolClass.name,
            SchoolClass.section,
            ClassSubject.subject_id,
            Subject.name,
            ClassSubject.teacher_id,
            Teacher.name,
        )
        .join(SchoolClass, SchoolClass.id == ClassSubject.class_id)
        .join(Subject, Subject.id == ClassSubject.subject_id)
        .outerjoin(Teacher, Teacher.id == ClassSubject.teacher_id)
        .order_by(SchoolClass.name, SchoolClass.section, Subject.name)
    )
    if class_id is not None:
        stmt = stmt.where(ClassSubject.class_id == class_id)
    if teacher_id is not None:
        stmt = stmt.where(ClassSubject.teacher_id == teacher_id)
    with session_scope() as session:
        rows = session.execute(stmt).all()
    data = [
        (r[0], r[1], class_label(r[2], r[3]), r[4], r[5], r[6], r[7] or "(unassigned)")
        for r in rows
    ]
    return pd.DataFrame(
        data, columns=["id", "class_id", "class", "subject_id", "subject", "teacher_id", "teacher"]
    )


def class_subject_options(
    class_id: int, teacher_id: Optional[int] = None
) -> list[tuple[int, str]]:
    """Subjects taught in a class; restricted to one teacher's subjects when given."""
    table = class_subject_table(class_id=class_id, teacher_id=teacher_id)
    return [(int(row.subject_id), str(row.subject)) for row in table.itertuples()]


def assign_subject(class_id: int, subject_id: int, teacher_id: Optional[int]) -> None:
    """Add a subject to a class, or change its teacher if it is already there."""
    with session_scope() as session:
        existing = session.scalar(
            select(ClassSubject).where(
                ClassSubject.class_id == class_id, ClassSubject.subject_id == subject_id
            )
        )
        if existing is not None:
            existing.teacher_id = teacher_id
        else:
            session.add(
                ClassSubject(class_id=class_id, subject_id=subject_id, teacher_id=teacher_id)
            )


def remove_assignment(assignment_id: int) -> None:
    with session_scope() as session:
        assignment = session.get(ClassSubject, assignment_id)
        if assignment is None:
            raise ValidationError("Assignment not found.")
        session.delete(assignment)
