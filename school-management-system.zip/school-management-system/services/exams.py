"""Exams, marks entry, grading, class results and report-card data."""
from __future__ import annotations

from typing import Any, Optional

import pandas as pd
from sqlalchemy import func, select

from database.models import ClassSubject, Exam, Result, SchoolClass, Student, Subject
from database.session import session_scope
from services._common import class_label, integrity_guard
from utils.config import GRADE_SCALE, PASS_PERCENT
from utils.validators import ValidationError, coerce_date, positive_int, require_text


def grade_for(percent: Optional[float]) -> tuple[str, str]:
    """Map a percentage to ``(grade, remark)`` using ``config.GRADE_SCALE``."""
    if percent is None or pd.isna(percent):
        return "-", ""
    for minimum, grade, remark in GRADE_SCALE:
        if percent >= minimum:
            return grade, remark
    return GRADE_SCALE[-1][1], GRADE_SCALE[-1][2]


# --------------------------------------------------------------------------
# Exams
# --------------------------------------------------------------------------
def list_exams() -> pd.DataFrame:
    with session_scope() as session:
        rows = session.execute(
            select(Exam.id, Exam.name, Exam.exam_date, Exam.max_marks).order_by(
                Exam.exam_date.desc(), Exam.id.desc()
            )
        ).all()
    return pd.DataFrame(
        [tuple(row) for row in rows], columns=["id", "name", "exam_date", "max_marks"]
    )


def get_exam(exam_id: int) -> Optional[dict]:
    with session_scope() as session:
        exam = session.get(Exam, exam_id)
        if exam is None:
            return None
        return {
            "id": exam.id,
            "name": exam.name,
            "exam_date": exam.exam_date,
            "max_marks": exam.max_marks,
        }


def add_exam(name: str, exam_date: Any, max_marks: Any) -> None:
    name = require_text(name, "Exam name", 100)
    day = coerce_date(exam_date, "Exam date", required=False)
    maximum = positive_int(max_marks, "Maximum marks", 1000)
    with integrity_guard("An exam with this name already exists."), session_scope() as session:
        session.add(Exam(name=name, exam_date=day, max_marks=maximum))


def delete_exam(exam_id: int) -> None:
    with session_scope() as session:
        exam = session.get(Exam, exam_id)
        if exam is None:
            raise ValidationError("Exam not found.")
        session.delete(exam)  # results cascade


# --------------------------------------------------------------------------
# Marks entry
# --------------------------------------------------------------------------
def marks_sheet(exam_id: int, class_id: int, subject_id: int) -> pd.DataFrame:
    """Roster with any marks already entered: ``student_id, roll_no, name, marks``."""
    with session_scope() as session:
        students = session.execute(
            select(Student.id, Student.roll_no, Student.name)
            .where(Student.class_id == class_id)
            .order_by(func.length(Student.roll_no), Student.roll_no)
        ).all()
        marks = dict(
            session.execute(
                select(Result.student_id, Result.marks).where(
                    Result.exam_id == exam_id,
                    Result.subject_id == subject_id,
                    Result.student_id.in_([row[0] for row in students]),
                )
            ).all()
        )
    sheet = pd.DataFrame(
        [(row[0], row[1], row[2], marks.get(row[0])) for row in students],
        columns=["student_id", "roll_no", "name", "marks"],
    )
    sheet["marks"] = pd.to_numeric(sheet["marks"], errors="coerce")
    return sheet


def save_marks(
    exam_id: int,
    class_id: int,
    subject_id: int,
    marks: dict[int, Optional[float]],
    teacher_id: Optional[int] = None,
) -> int:
    """Save (or clear, when ``None``) marks. Teachers may only grade their own subjects."""
    with session_scope() as session:
        exam = session.get(Exam, exam_id)
        if exam is None:
            raise ValidationError("Exam not found.")

        assignment = session.scalar(
            select(ClassSubject).where(
                ClassSubject.class_id == class_id, ClassSubject.subject_id == subject_id
            )
        )
        if assignment is None:
            raise ValidationError("This subject is not taught in the selected class.")
        if teacher_id is not None and assignment.teacher_id != teacher_id:
            raise ValidationError("You can only enter marks for subjects assigned to you.")

        valid_ids = set(
            session.scalars(select(Student.id).where(Student.class_id == class_id)).all()
        )
        existing = {
            row.student_id: row
            for row in session.scalars(
                select(Result).where(
                    Result.exam_id == exam_id,
                    Result.subject_id == subject_id,
                    Result.student_id.in_(list(valid_ids)),
                )
            )
        }
        saved = 0
        for student_id, value in marks.items():
            if student_id not in valid_ids:
                continue
            record = existing.get(student_id)
            if value is None or pd.isna(value):
                if record is not None:
                    session.delete(record)
                continue
            score = float(value)
            if score < 0 or score > exam.max_marks:
                raise ValidationError(f"Marks must be between 0 and {exam.max_marks}.")
            if record is None:
                session.add(
                    Result(
                        exam_id=exam_id, student_id=student_id, subject_id=subject_id, marks=score
                    )
                )
            else:
                record.marks = score
            saved += 1
    return saved


# --------------------------------------------------------------------------
# Results
# --------------------------------------------------------------------------
def class_results(exam_id: int, class_id: int) -> pd.DataFrame:
    """Totals, percentage, grade, pass/fail and rank for every student in a class."""
    exam = get_exam(exam_id)
    columns = ["student_id", "roll_no", "name", "subjects", "total", "max_total",
               "percentage", "grade", "status", "rank"]
    if exam is None:
        return pd.DataFrame(columns=columns)
    with session_scope() as session:
        students = session.execute(
            select(Student.id, Student.roll_no, Student.name)
            .where(Student.class_id == class_id)
            .order_by(func.length(Student.roll_no), Student.roll_no)
        ).all()
        aggregates = {
            row[0]: (row[1], row[2], row[3])
            for row in session.execute(
                select(
                    Result.student_id,
                    func.count(Result.id),
                    func.sum(Result.marks),
                    func.min(Result.marks),
                )
                .where(
                    Result.exam_id == exam_id,
                    Result.student_id.in_([row[0] for row in students]),
                )
                .group_by(Result.student_id)
            ).all()
        }
    rows = []
    for sid, roll, name in students:
        if sid not in aggregates:
            rows.append((sid, roll, name, 0, None, None, None, "-", "No results", None))
            continue
        count, total, lowest = aggregates[sid]
        max_total = count * exam["max_marks"]
        percent = round(total / max_total * 100, 2)
        failed = (lowest / exam["max_marks"] * 100) < PASS_PERCENT
        rows.append(
            (sid, roll, name, count, total, max_total, percent,
             grade_for(percent)[0], "Fail" if failed else "Pass", None)
        )
    df = pd.DataFrame(rows, columns=columns)
    for column in ("total", "max_total", "percentage"):
        df[column] = pd.to_numeric(df[column], errors="coerce")
    df["rank"] = df["percentage"].rank(method="min", ascending=False).astype("Int64")
    return df


def student_result(exam_id: int, student_id: int) -> Optional[dict]:
    """Everything needed for a report card, or ``None`` if the student has no marks."""
    exam = get_exam(exam_id)
    if exam is None:
        return None
    with session_scope() as session:
        student = session.execute(
            select(
                Student.id, Student.roll_no, Student.name, Student.guardian_name,
                Student.class_id, SchoolClass.name, SchoolClass.section,
            )
            .join(SchoolClass, SchoolClass.id == Student.class_id)
            .where(Student.id == student_id)
        ).first()
        if student is None:
            return None
        rows = session.execute(
            select(Subject.name, Result.marks)
            .join(Subject, Subject.id == Result.subject_id)
            .where(Result.exam_id == exam_id, Result.student_id == student_id)
            .order_by(Subject.name)
        ).all()
    if not rows:
        return None

    subjects = []
    for subject_name, marks in rows:
        percent = round(marks / exam["max_marks"] * 100, 1)
        subjects.append(
            {
                "subject": subject_name,
                "marks": marks,
                "max_marks": exam["max_marks"],
                "percentage": percent,
                "grade": grade_for(percent)[0],
            }
        )
    total = sum(item["marks"] for item in subjects)
    max_total = len(subjects) * exam["max_marks"]
    percent = round(total / max_total * 100, 2)
    grade, remark = grade_for(percent)
    failed = any(item["percentage"] < PASS_PERCENT for item in subjects)

    standings = class_results(exam_id, student[4])
    mine = standings[standings["student_id"] == student_id]
    rank = None if mine.empty or pd.isna(mine.iloc[0]["rank"]) else int(mine.iloc[0]["rank"])

    return {
        "exam": exam,
        "student": {
            "id": student[0],
            "roll_no": student[1],
            "name": student[2],
            "guardian_name": student[3],
            "class": class_label(student[5], student[6]),
        },
        "subjects": pd.DataFrame(subjects),
        "total": total,
        "max_total": max_total,
        "percentage": percent,
        "grade": grade,
        "remark": remark,
        "status": "Fail" if failed else "Pass",
        "rank": rank,
        "class_size": int(standings["rank"].notna().sum()),
    }


def student_exams(student_id: int) -> pd.DataFrame:
    """Exams for which a student has at least one mark (newest first)."""
    stmt = (
        select(Exam.id, Exam.name, Exam.exam_date, Exam.max_marks)
        .join(Result, Result.exam_id == Exam.id)
        .where(Result.student_id == student_id)
        .distinct()
        .order_by(Exam.exam_date.desc(), Exam.id.desc())
    )
    with session_scope() as session:
        rows = session.execute(stmt).all()
    return pd.DataFrame(
        [tuple(row) for row in rows], columns=["id", "name", "exam_date", "max_marks"]
    )
