"""Business logic. Services return pandas DataFrames or plain dicts, never ORM objects."""
