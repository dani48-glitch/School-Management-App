"""Authentication and user-account management."""
from __future__ import annotations

from datetime import timedelta
from functools import lru_cache
from typing import Optional

import pandas as pd
from sqlalchemy import func, select

from database.models import User, utcnow
from database.session import session_scope
from services._common import integrity_guard, rows_to_df
from utils.config import LOCKOUT_MINUTES, MAX_FAILED_LOGINS, ROLES
from utils.security import hash_password, validate_password_strength, verify_password
from utils.validators import ValidationError, require_text, validate_username

_INVALID = "Invalid username or password."


@lru_cache(maxsize=1)
def _dummy_hash() -> str:
    """Hash used to burn comparable time when the username does not exist."""
    return hash_password("not-a-real-password-1")


def authenticate(username: str, password: str) -> dict:
    """Verify credentials and return the session user dict, or raise ValidationError."""
    username = (username or "").strip().lower()
    password = password or ""
    if not username or not password:
        raise ValidationError("Enter your username and password.")

    with session_scope() as session:
        user = session.scalar(select(User).where(User.username == username))
        if user is None:
            verify_password(password, _dummy_hash())
            raise ValidationError(_INVALID)

        now = utcnow()
        if user.locked_until and user.locked_until > now:
            minutes = int((user.locked_until - now).total_seconds() // 60) + 1
            raise ValidationError(f"Too many failed attempts. Try again in {minutes} minute(s).")

        if not verify_password(password, user.password_hash):
            user.failed_attempts = (user.failed_attempts or 0) + 1
            if user.failed_attempts >= MAX_FAILED_LOGINS:
                user.locked_until = now + timedelta(minutes=LOCKOUT_MINUTES)
                user.failed_attempts = 0
            session.commit()  # persist the counter before raising
            raise ValidationError(_INVALID)

        if not user.is_active:
            raise ValidationError("This account is disabled. Please contact the administrator.")

        user.failed_attempts = 0
        user.locked_until = None
        return {
            "id": user.id,
            "username": user.username,
            "role": user.role,
            "full_name": user.full_name,
            "student_id": user.student_id,
            "teacher_id": user.teacher_id,
        }


def list_users() -> pd.DataFrame:
    stmt = select(
        User.id, User.username, User.full_name, User.role, User.is_active, User.created_at
    ).order_by(User.role, User.username)
    with session_scope() as session:
        rows = session.execute(stmt).all()
    return rows_to_df(rows, ["id", "username", "full_name", "role", "active", "created"])


def _check_other_admin_exists(session, user_id: int) -> None:
    """Refuse changes that would leave the school without an active administrator."""
    others = session.scalar(
        select(func.count(User.id)).where(
            User.role == "admin", User.is_active.is_(True), User.id != user_id
        )
    )
    if not others:
        raise ValidationError("There must be at least one active administrator.")


def create_user(
    username: str,
    password: str,
    role: str,
    full_name: str,
    student_id: Optional[int] = None,
    teacher_id: Optional[int] = None,
) -> int:
    username = validate_username(username)
    problem = validate_password_strength(password)
    if problem:
        raise ValidationError(problem)
    if role not in ROLES:
        raise ValidationError("Choose a valid role.")
    if role == "student" and not student_id:
        raise ValidationError("Select the student this account belongs to.")
    if role == "teacher" and not teacher_id:
        raise ValidationError("Select the teacher this account belongs to.")
    full_name = require_text(full_name, "Full name")

    with integrity_guard("That username is already taken."), session_scope() as session:
        user = User(
            username=username,
            password_hash=hash_password(password),
            role=role,
            full_name=full_name,
            student_id=student_id if role == "student" else None,
            teacher_id=teacher_id if role == "teacher" else None,
        )
        session.add(user)
        session.flush()
        return user.id


def reset_password(user_id: int, new_password: str) -> None:
    problem = validate_password_strength(new_password)
    if problem:
        raise ValidationError(problem)
    with session_scope() as session:
        user = session.get(User, user_id)
        if user is None:
            raise ValidationError("User not found.")
        user.password_hash = hash_password(new_password)
        user.failed_attempts = 0
        user.locked_until = None


def set_active(user_id: int, active: bool, acting_user_id: int) -> None:
    if user_id == acting_user_id and not active:
        raise ValidationError("You cannot disable your own account.")
    with session_scope() as session:
        user = session.get(User, user_id)
        if user is None:
            raise ValidationError("User not found.")
        if not active and user.role == "admin":
            _check_other_admin_exists(session, user.id)
        user.is_active = active
        if active:
            user.failed_attempts = 0
            user.locked_until = None


def delete_user(user_id: int, acting_user_id: int) -> None:
    if user_id == acting_user_id:
        raise ValidationError("You cannot delete your own account.")
    with session_scope() as session:
        user = session.get(User, user_id)
        if user is None:
            raise ValidationError("User not found.")
        if user.role == "admin":
            _check_other_admin_exists(session, user.id)
        session.delete(user)


def change_password(user_id: int, current: str, new: str, confirm: str) -> None:
    """Self-service password change for the signed-in user."""
    if new != confirm:
        raise ValidationError("The new passwords do not match.")
    problem = validate_password_strength(new)
    if problem:
        raise ValidationError(problem)
    with session_scope() as session:
        user = session.get(User, user_id)
        if user is None:
            raise ValidationError("User not found.")
        if not verify_password(current or "", user.password_hash):
            raise ValidationError("Your current password is incorrect.")
        if current == new:
            raise ValidationError("Choose a password different from the current one.")
        user.password_hash = hash_password(new)
