"""Aggregates for the dashboards."""
from __future__ import annotations

from datetime import timedelta

import pandas as pd
from sqlalchemy import func, select

from database.models import (
    Attendance,
    ClassSubject,
    Exam,
    Result,
    SchoolClass,
    Student,
    Subject,
    Teacher,
)
from database.session import session_scope
from services import attendance, exams, fees
from utils.clock import today


def admin_metrics() -> dict:
    current = today()
    with session_scope() as session:
        students = session.scalar(select(func.count(Student.id))) or 0
        teachers = session.scalar(select(func.count(Teacher.id))) or 0
        classes = session.scalar(select(func.count(SchoolClass.id))) or 0
        status_counts = dict(
            session.execute(
                select(Attendance.status, func.count())
                .where(Attendance.att_date == current)
                .group_by(Attendance.status)
            ).all()
        )
    marked = sum(status_counts.values())
    present = status_counts.get("Present", 0) + status_counts.get("Late", 0)

    dues = fees.dues_table()
    expected = int(dues["total_fee"].sum()) if not dues.empty else 0
    collected = int(dues["paid"].sum()) if not dues.empty else 0
    pending = int(dues["pending"].sum()) if not dues.empty else 0
    return {
        "students": students,
        "teachers": teachers,
        "classes": classes,
        "marked_today": marked,
        "present_today": present,
        "attendance_pct": attendance.percentage(present, 0, marked),
        "fees_expected": expected,
        "fees_collected": collected,
        "fees_pending": pending,
    }


def attendance_trend(days: int = 14) -> pd.DataFrame:
    """School-wide attendance % per day for the last ``days`` days."""
    start = today() - timedelta(days=days)
    with session_scope() as session:
        rows = session.execute(
            select(Attendance.att_date, Attendance.status, func.count())
            .where(Attendance.att_date >= start)
            .group_by(Attendance.att_date, Attendance.status)
        ).all()
    per_day: dict = {}
    for day, status, count in rows:
        bucket = per_day.setdefault(day, {"present": 0, "marked": 0})
        bucket["marked"] += count
        if status in ("Present", "Late"):
            bucket["present"] += count
    data = [
        (day, round(values["present"] / values["marked"] * 100, 1))
        for day, values in sorted(per_day.items())
    ]
    return pd.DataFrame(data, columns=["date", "attendance_pct"])


def fees_by_class() -> pd.DataFrame:
    dues = fees.dues_table()
    if dues.empty:
        return pd.DataFrame(columns=["class", "collected", "pending"])
    grouped = dues.groupby("class", as_index=False)[["paid", "pending"]].sum()
    return grouped.rename(columns={"paid": "collected"})


def latest_exam_id() -> int | None:
    table = exams.list_exams()
    return None if table.empty else int(table.iloc[0]["id"])


def subject_averages(exam_id: int) -> pd.DataFrame:
    """Average percentage per subject for one exam, school-wide."""
    with session_scope() as session:
        max_marks = session.scalar(select(Exam.max_marks).where(Exam.id == exam_id))
        rows = session.execute(
            select(Subject.name, func.avg(Result.marks))
            .join(Subject, Subject.id == Result.subject_id)
            .where(Result.exam_id == exam_id)
            .group_by(Subject.name)
            .order_by(Subject.name)
        ).all()
    if not max_marks:
        return pd.DataFrame(columns=["subject", "average_pct"])
    return pd.DataFrame(
        [(name, round(avg / max_marks * 100, 1)) for name, avg in rows],
        columns=["subject", "average_pct"],
    )


def teacher_metrics(teacher_id: int) -> dict:
    with session_scope() as session:
        class_ids = list(
            session.scalars(
                select(ClassSubject.class_id)
                .where(ClassSubject.teacher_id == teacher_id)
                .distinct()
            )
        )
        subjects = (
            session.scalar(
                select(func.count(func.distinct(ClassSubject.subject_id))).where(
                    ClassSubject.teacher_id == teacher_id
                )
            )
            or 0
        )
        students = (
            session.scalar(select(func.count(Student.id)).where(Student.class_id.in_(class_ids)))
            or 0
        )
    return {"classes": len(class_ids), "subjects": subjects, "students": students}


def student_metrics(student_id: int) -> dict:
    summary = attendance.student_summary(student_id)
    student_exam_table = exams.student_exams(student_id)
    latest = None
    if not student_exam_table.empty:
        latest = exams.student_result(int(student_exam_table.iloc[0]["id"]), student_id)
    return {
        "attendance": summary,
        "latest_result": latest,
        "fees": fees.student_fee_summary(student_id),
    }
