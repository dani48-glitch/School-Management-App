"""PDF generation (report cards and fee receipts) with fpdf2.

Built-in PDF fonts only cover Latin-1 text. Characters outside that range are
replaced with "?"; to print other scripts (for example Urdu), register a
Unicode TTF font with ``pdf.add_font`` and use it instead of Helvetica.
"""
from __future__ import annotations

from typing import Any, Sequence

from fpdf import FPDF

_GREEN = (31, 111, 92)
_LIGHT = (235, 243, 240)


def _txt(value: Any) -> str:
    """Make any value safe for the built-in Latin-1 PDF fonts."""
    text = "" if value is None else str(value)
    return text.encode("latin-1", "replace").decode("latin-1")


def _new_pdf(page_format: str = "A4") -> FPDF:
    pdf = FPDF(orientation="P", unit="mm", format=page_format)
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.set_margins(15, 15, 15)
    pdf.add_page()
    return pdf


def _heading(pdf: FPDF, school_name: str, title: str, subtitle: str = "") -> None:
    pdf.set_text_color(*_GREEN)
    pdf.set_font("Helvetica", "B", 18)
    pdf.cell(0, 10, _txt(school_name), align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Helvetica", "B", 13)
    pdf.set_text_color(40, 40, 40)
    pdf.cell(0, 8, _txt(title), align="C", new_x="LMARGIN", new_y="NEXT")
    if subtitle:
        pdf.set_font("Helvetica", "", 10)
        pdf.cell(0, 6, _txt(subtitle), align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.set_draw_color(*_GREEN)
    pdf.set_line_width(0.6)
    y = pdf.get_y() + 2
    pdf.line(pdf.l_margin, y, pdf.w - pdf.r_margin, y)
    pdf.ln(6)
    pdf.set_text_color(0, 0, 0)
    pdf.set_line_width(0.2)
    pdf.set_draw_color(120, 120, 120)


def _table_row(
    pdf: FPDF,
    widths: Sequence[float],
    values: Sequence[Any],
    aligns: Sequence[str],
    bold: bool = False,
    fill: bool = False,
    height: float = 8,
) -> None:
    pdf.set_font("Helvetica", "B" if bold else "", 10)
    for width, value, align in zip(widths, values, aligns):
        pdf.cell(width, height, _txt(value), border=1, align=align, fill=fill,
                 new_x="RIGHT", new_y="TOP")
    pdf.ln(height)


def _label_value(pdf: FPDF, label: str, value: Any, label_width: float = 38) -> None:
    pdf.set_font("Helvetica", "B", 10)
    pdf.cell(label_width, 7, _txt(label), new_x="RIGHT", new_y="TOP")
    pdf.set_font("Helvetica", "", 10)
    pdf.cell(0, 7, _txt(value), new_x="LMARGIN", new_y="NEXT")


def report_card_pdf(result: dict, school_name: str) -> bytes:
    """Render a student's report card (``exams.student_result`` output) as PDF bytes."""
    pdf = _new_pdf("A4")
    exam = result["exam"]
    student = result["student"]
    _heading(pdf, school_name, "REPORT CARD", exam["name"])

    _label_value(pdf, "Student name:", student["name"])
    _label_value(pdf, "Roll no.:", student["roll_no"])
    _label_value(pdf, "Class:", student["class"])
    _label_value(pdf, "Guardian:", student["guardian_name"])
    if exam.get("exam_date"):
        _label_value(pdf, "Exam date:", exam["exam_date"].strftime("%d %b %Y"))
    pdf.ln(4)

    widths = [70, 35, 30, 25, 20]
    aligns = ["L", "C", "C", "C", "C"]
    pdf.set_fill_color(*_GREEN)
    pdf.set_text_color(255, 255, 255)
    _table_row(pdf, widths, ["Subject", "Marks obtained", "Maximum", "Percent", "Grade"],
               aligns, bold=True, fill=True)
    pdf.set_text_color(0, 0, 0)
    pdf.set_fill_color(*_LIGHT)
    for index, row in enumerate(result["subjects"].itertuples()):
        _table_row(
            pdf, widths,
            [row.subject, f"{row.marks:g}", f"{row.max_marks:g}", f"{row.percentage:.1f}%",
             row.grade],
            aligns, fill=index % 2 == 1,
        )
    _table_row(
        pdf, widths,
        ["TOTAL", f"{result['total']:g}", f"{result['max_total']:g}",
         f"{result['percentage']:.2f}%", result["grade"]],
        aligns, bold=True, fill=True,
    )
    pdf.ln(6)

    _label_value(pdf, "Result:", result["status"])
    _label_value(pdf, "Overall grade:", f"{result['grade']} ({result['remark']})")
    if result.get("rank"):
        _label_value(pdf, "Class position:", f"{result['rank']} of {result['class_size']}")

    pdf.ln(22)
    y = pdf.get_y()
    pdf.line(20, y, 80, y)
    pdf.line(pdf.w - 80, y, pdf.w - 20, y)
    pdf.set_font("Helvetica", "", 9)
    pdf.set_xy(20, y + 1)
    pdf.cell(60, 5, "Class teacher", align="C")
    pdf.set_xy(pdf.w - 80, y + 1)
    pdf.cell(60, 5, "Principal", align="C")
    return bytes(pdf.output())


def receipt_pdf(receipt: dict, school_name: str, currency: str) -> bytes:
    """Render a fee receipt (``fees.get_receipt`` output) as an A5 PDF."""
    pdf = _new_pdf("A5")
    _heading(pdf, school_name, "FEE RECEIPT", f"Receipt no. {receipt['receipt_no']}")

    _label_value(pdf, "Date:", receipt["paid_on"].strftime("%d %b %Y"), 34)
    _label_value(pdf, "Student:", receipt["student_name"], 34)
    _label_value(pdf, "Roll no.:", receipt["roll_no"], 34)
    _label_value(pdf, "Class:", receipt["class"], 34)
    _label_value(pdf, "Guardian:", receipt["guardian_name"], 34)
    _label_value(pdf, "Payment method:", receipt["method"], 34)
    pdf.ln(3)

    pdf.set_fill_color(*_LIGHT)
    pdf.set_font("Helvetica", "B", 14)
    pdf.cell(0, 12, _txt(f"Amount received: {currency} {receipt['amount']:,}"), border=1,
             align="C", fill=True, new_x="LMARGIN", new_y="NEXT")
    pdf.ln(3)

    _label_value(pdf, "Total fee:", f"{currency} {receipt['total_fee']:,}", 34)
    _label_value(pdf, "Paid to date:", f"{currency} {receipt['paid_to_date']:,}", 34)
    _label_value(pdf, "Balance due:", f"{currency} {receipt['balance']:,}", 34)
    if receipt.get("note"):
        _label_value(pdf, "Note:", receipt["note"], 34)
    if receipt.get("received_by"):
        _label_value(pdf, "Received by:", receipt["received_by"], 34)

    pdf.ln(6)
    pdf.set_font("Helvetica", "I", 8)
    pdf.set_text_color(110, 110, 110)
    pdf.cell(0, 5, "This is a computer-generated receipt.", align="C")
    return bytes(pdf.output())
