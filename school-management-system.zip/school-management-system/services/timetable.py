"""Weekly timetable per class and per teacher, with teacher-clash detection."""
from __future__ import annotations

from typing import Optional

import pandas as pd
from sqlalchemy import select

from database.models import SchoolClass, Subject, Teacher, TimetableEntry
from database.session import session_scope
from services._common import class_label
from utils.config import DAYS, PERIODS
from utils.validators import ValidationError, optional_text


def period_label(period: int) -> str:
    return f"P{period} · {PERIODS[period]}"


def _empty_grid() -> pd.DataFrame:
    return pd.DataFrame("", index=[period_label(p) for p in PERIODS], columns=DAYS)


def entries(class_id: int) -> pd.DataFrame:
    """Raw slots of a class: ``id, day, period, subject_id, subject, teacher_id, teacher, room``."""
    stmt = (
        select(
            TimetableEntry.id, TimetableEntry.day, TimetableEntry.period,
            TimetableEntry.subject_id, Subject.name, TimetableEntry.teacher_id,
            Teacher.name, TimetableEntry.room,
        )
        .join(Subject, Subject.id == TimetableEntry.subject_id)
        .outerjoin(Teacher, Teacher.id == TimetableEntry.teacher_id)
        .where(TimetableEntry.class_id == class_id)
        .order_by(TimetableEntry.day, TimetableEntry.period)
    )
    with session_scope() as session:
        rows = session.execute(stmt).all()
    return pd.DataFrame(
        [tuple(row) for row in rows],
        columns=["id", "day", "period", "subject_id", "subject", "teacher_id", "teacher", "room"],
    )


def class_grid(class_id: int) -> pd.DataFrame:
    """Periods x days grid for a class; each cell reads ``Subject (Teacher)``."""
    grid = _empty_grid()
    for row in entries(class_id).itertuples():
        if row.period in PERIODS and 0 <= row.day < len(DAYS):
            teacher = row.teacher if isinstance(row.teacher, str) else ""
            text = f"{row.subject} ({teacher})" if teacher else str(row.subject)
            grid.at[period_label(row.period), DAYS[row.day]] = text
    return grid


def teacher_grid(teacher_id: int) -> pd.DataFrame:
    """Periods x days grid for a teacher; each cell reads ``Subject (Class)``."""
    stmt = (
        select(
            TimetableEntry.day, TimetableEntry.period, Subject.name,
            SchoolClass.name, SchoolClass.section,
        )
        .join(Subject, Subject.id == TimetableEntry.subject_id)
        .join(SchoolClass, SchoolClass.id == TimetableEntry.class_id)
        .where(TimetableEntry.teacher_id == teacher_id)
    )
    with session_scope() as session:
        rows = session.execute(stmt).all()
    grid = _empty_grid()
    for day, period, subject, class_name, section in rows:
        if period in PERIODS and 0 <= day < len(DAYS):
            grid.at[period_label(period), DAYS[day]] = (
                f"{subject} ({class_label(class_name, section)})"
            )
    return grid


def day_schedule(grid: pd.DataFrame, weekday: int) -> pd.DataFrame:
    """One day of a grid as ``period, subject`` rows (empty for weekends)."""
    if not 0 <= weekday < len(DAYS):
        return pd.DataFrame(columns=["period", "lesson"])
    column = grid[DAYS[weekday]]
    return pd.DataFrame({"period": column.index, "lesson": column.values})


def save_entry(
    class_id: int,
    day: int,
    period: int,
    subject_id: int,
    teacher_id: Optional[int],
    room: Optional[str],
) -> None:
    """Create or replace one slot, refusing to double-book a teacher."""
    if day not in range(len(DAYS)):
        raise ValidationError("Choose a valid day.")
    if period not in PERIODS:
        raise ValidationError("Choose a valid period.")
    room_value = optional_text(room, "Room", 20)

    with session_scope() as session:
        if teacher_id is not None:
            clash = session.execute(
                select(SchoolClass.name, SchoolClass.section)
                .join(TimetableEntry, TimetableEntry.class_id == SchoolClass.id)
                .where(
                    TimetableEntry.teacher_id == teacher_id,
                    TimetableEntry.day == day,
                    TimetableEntry.period == period,
                    TimetableEntry.class_id != class_id,
                )
            ).first()
            if clash is not None:
                raise ValidationError(
                    f"That teacher is already teaching {class_label(clash[0], clash[1])} "
                    f"on {DAYS[day]} in period {period}."
                )
        existing = session.scalar(
            select(TimetableEntry).where(
                TimetableEntry.class_id == class_id,
                TimetableEntry.day == day,
                TimetableEntry.period == period,
            )
        )
        if existing is None:
            session.add(
                TimetableEntry(
                    class_id=class_id, day=day, period=period, subject_id=subject_id,
                    teacher_id=teacher_id, room=room_value,
                )
            )
        else:
            existing.subject_id = subject_id
            existing.teacher_id = teacher_id
            existing.room = room_value


def delete_entry(class_id: int, day: int, period: int) -> None:
    with session_scope() as session:
        entry = session.scalar(
            select(TimetableEntry).where(
                TimetableEntry.class_id == class_id,
                TimetableEntry.day == day,
                TimetableEntry.period == period,
            )
        )
        if entry is None:
            raise ValidationError("That slot is already empty.")
        session.delete(entry)
