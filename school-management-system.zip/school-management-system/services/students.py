"""Student records."""
from __future__ import annotations

from typing import Any, Optional, Sequence

import pandas as pd
from sqlalchemy import func, or_, select

from database.models import SchoolClass, Student
from database.session import session_scope
from services._common import class_label, integrity_guard, like_pattern
from utils.validators import ValidationError, require_text, validate_dob, validate_phone

COLUMNS = ["id", "roll_no", "name", "class_id", "class", "dob", "guardian_name", "phone", "address"]
_ESC = "\\"


def _validated(fields: dict[str, Any]) -> dict[str, Any]:
    """Validate and normalise whichever student fields were supplied."""
    out: dict[str, Any] = {}
    if "roll_no" in fields:
        out["roll_no"] = require_text(fields["roll_no"], "Roll no.", 20)
    if "name" in fields:
        out["name"] = require_text(fields["name"], "Name", 100)
    if "class_id" in fields:
        if fields["class_id"] is None:
            raise ValidationError("Class is required.")
        out["class_id"] = int(fields["class_id"])
    if "dob" in fields:
        out["dob"] = validate_dob(fields["dob"])
    if "guardian_name" in fields:
        out["guardian_name"] = require_text(fields["guardian_name"], "Guardian name", 100)
    if "phone" in fields:
        out["phone"] = validate_phone(fields["phone"], "Phone")
    if "address" in fields:
        out["address"] = require_text(fields["address"], "Address", 300)
    return out


def list_students(
    search: str = "",
    class_id: Optional[int] = None,
    class_ids: Optional[Sequence[int]] = None,
) -> pd.DataFrame:
    """Students matching a text search, one class, and/or a set of allowed classes."""
    stmt = (
        select(
            Student.id,
            Student.roll_no,
            Student.name,
            Student.class_id,
            SchoolClass.name,
            SchoolClass.section,
            Student.dob,
            Student.guardian_name,
            Student.phone,
            Student.address,
        )
        .join(SchoolClass, SchoolClass.id == Student.class_id)
        .order_by(
            SchoolClass.name, SchoolClass.section, func.length(Student.roll_no), Student.roll_no
        )
    )
    if class_id is not None:
        stmt = stmt.where(Student.class_id == class_id)
    if class_ids is not None:
        stmt = stmt.where(Student.class_id.in_(list(class_ids)))
    if search and search.strip():
        pattern = like_pattern(search)
        stmt = stmt.where(
            or_(
                Student.name.ilike(pattern, escape=_ESC),
                Student.roll_no.ilike(pattern, escape=_ESC),
                Student.guardian_name.ilike(pattern, escape=_ESC),
                Student.phone.ilike(pattern, escape=_ESC),
            )
        )
    with session_scope() as session:
        rows = session.execute(stmt).all()
    data = [
        (r[0], r[1], r[2], r[3], class_label(r[4], r[5]), r[6], r[7], r[8], r[9]) for r in rows
    ]
    return pd.DataFrame(data, columns=COLUMNS)


def student_options(class_id: Optional[int] = None) -> list[tuple[int, str]]:
    """``(id, label)`` pairs for selectboxes."""
    df = list_students(class_id=class_id)
    return [
        (int(sid), f"{roll} - {name} ({klass})")
        for sid, roll, name, klass in zip(df["id"], df["roll_no"], df["name"], df["class"])
    ]


def get_student(student_id: int) -> Optional[dict]:
    df = list_students()
    match = df[df["id"] == student_id]
    if match.empty:
        return None
    return match.iloc[0].to_dict()


def add_student(
    roll_no: str,
    name: str,
    class_id: Optional[int],
    dob: Any,
    guardian_name: str,
    phone: str,
    address: str,
) -> int:
    data = _validated(
        {
            "roll_no": roll_no,
            "name": name,
            "class_id": class_id,
            "dob": dob,
            "guardian_name": guardian_name,
            "phone": phone,
            "address": address,
        }
    )
    with integrity_guard("That roll number is already used in this class."), session_scope() as s:
        student = Student(**data)
        s.add(student)
        s.flush()
        return student.id


def update_student(student_id: int, **fields: Any) -> None:
    data = _validated(fields)
    with integrity_guard("That roll number is already used in this class."), session_scope() as s:
        student = s.get(Student, student_id)
        if student is None:
            raise ValidationError("Student not found.")
        for attribute, value in data.items():
            setattr(student, attribute, value)


def delete_student(student_id: int) -> None:
    with session_scope() as session:
        student = session.get(Student, student_id)
        if student is None:
            raise ValidationError("Student not found.")
        session.delete(student)  # attendance, results, payments and logins cascade
