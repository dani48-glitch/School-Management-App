"""Teacher profiles and their class/subject assignments."""
from __future__ import annotations

from typing import Any, Optional

import pandas as pd
from sqlalchemy import or_, select

from database.models import ClassSubject, SchoolClass, Subject, Teacher
from database.session import session_scope
from services._common import class_label, integrity_guard, like_pattern
from utils.validators import (
    ValidationError,
    coerce_date,
    optional_text,
    require_text,
    validate_email,
    validate_phone,
)

_ESC = "\\"
COLUMNS = ["id", "name", "email", "phone", "qualification", "joined_on", "subjects", "classes"]


def _validated(fields: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    if "name" in fields:
        out["name"] = require_text(fields["name"], "Name", 100)
    if "email" in fields:
        out["email"] = validate_email(fields["email"])
    if "phone" in fields:
        out["phone"] = validate_phone(fields["phone"], "Phone", required=False)
    if "qualification" in fields:
        out["qualification"] = optional_text(fields["qualification"], "Qualification", 120)
    if "joined_on" in fields:
        out["joined_on"] = coerce_date(fields["joined_on"], "Joining date", required=False)
    return out


def teacher_options() -> list[tuple[int, str]]:
    with session_scope() as session:
        rows = session.execute(select(Teacher.id, Teacher.name).order_by(Teacher.name)).all()
    return [(row[0], row[1]) for row in rows]


def list_teachers(search: str = "") -> pd.DataFrame:
    stmt = select(
        Teacher.id,
        Teacher.name,
        Teacher.email,
        Teacher.phone,
        Teacher.qualification,
        Teacher.joined_on,
    ).order_by(Teacher.name)
    if search and search.strip():
        pattern = like_pattern(search)
        stmt = stmt.where(
            or_(
                Teacher.name.ilike(pattern, escape=_ESC),
                Teacher.email.ilike(pattern, escape=_ESC),
                Teacher.phone.ilike(pattern, escape=_ESC),
            )
        )
    assignment_stmt = (
        select(ClassSubject.teacher_id, Subject.name, SchoolClass.name, SchoolClass.section)
        .join(Subject, Subject.id == ClassSubject.subject_id)
        .join(SchoolClass, SchoolClass.id == ClassSubject.class_id)
        .where(ClassSubject.teacher_id.is_not(None))
    )
    with session_scope() as session:
        teacher_rows = session.execute(stmt).all()
        assignment_rows = session.execute(assignment_stmt).all()

    subjects: dict[int, set[str]] = {}
    classes: dict[int, set[str]] = {}
    for teacher_id, subject_name, class_name, section in assignment_rows:
        subjects.setdefault(teacher_id, set()).add(subject_name)
        classes.setdefault(teacher_id, set()).add(class_label(class_name, section))

    data = [
        (
            row[0], row[1], row[2], row[3], row[4], row[5],
            ", ".join(sorted(subjects.get(row[0], set()))),
            ", ".join(sorted(classes.get(row[0], set()))),
        )
        for row in teacher_rows
    ]
    return pd.DataFrame(data, columns=COLUMNS)


def get_teacher(teacher_id: int) -> Optional[dict]:
    df = list_teachers()
    match = df[df["id"] == teacher_id]
    if match.empty:
        return None
    return match.iloc[0].to_dict()


def teacher_assignments(teacher_id: int) -> pd.DataFrame:
    stmt = (
        select(ClassSubject.class_id, SchoolClass.name, SchoolClass.section, Subject.name)
        .join(SchoolClass, SchoolClass.id == ClassSubject.class_id)
        .join(Subject, Subject.id == ClassSubject.subject_id)
        .where(ClassSubject.teacher_id == teacher_id)
        .order_by(SchoolClass.name, SchoolClass.section, Subject.name)
    )
    with session_scope() as session:
        rows = session.execute(stmt).all()
    data = [(r[0], class_label(r[1], r[2]), r[3]) for r in rows]
    return pd.DataFrame(data, columns=["class_id", "class", "subject"])


def teacher_class_ids(teacher_id: int) -> list[int]:
    with session_scope() as session:
        rows = session.scalars(
            select(ClassSubject.class_id).where(ClassSubject.teacher_id == teacher_id).distinct()
        ).all()
    return [int(row) for row in rows]


def add_teacher(
    name: str,
    email: Optional[str],
    phone: Optional[str],
    qualification: Optional[str],
    joined_on: Any,
) -> int:
    data = _validated(
        {
            "name": name,
            "email": email,
            "phone": phone,
            "qualification": qualification,
            "joined_on": joined_on,
        }
    )
    with integrity_guard("A teacher with this email already exists."), session_scope() as s:
        teacher = Teacher(**data)
        s.add(teacher)
        s.flush()
        return teacher.id


def update_teacher(teacher_id: int, **fields: Any) -> None:
    data = _validated(fields)
    with integrity_guard("A teacher with this email already exists."), session_scope() as s:
        teacher = s.get(Teacher, teacher_id)
        if teacher is None:
            raise ValidationError("Teacher not found.")
        for attribute, value in data.items():
            setattr(teacher, attribute, value)


def delete_teacher(teacher_id: int) -> None:
    with session_scope() as session:
        teacher = session.get(Teacher, teacher_id)
        if teacher is None:
            raise ValidationError("Teacher not found.")
        session.delete(teacher)  # logins cascade; assignments and timetable slots become unassigned
