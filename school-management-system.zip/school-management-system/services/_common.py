"""Helpers shared by the service modules."""
from __future__ import annotations

import secrets
from contextlib import contextmanager
from datetime import date
from typing import Iterable, Iterator, Sequence

import pandas as pd
from sqlalchemy.exc import IntegrityError

from utils.validators import ValidationError


def rows_to_df(rows: Iterable, columns: Sequence[str]) -> pd.DataFrame:
    """Turn SQLAlchemy result rows into a DataFrame with the given column names."""
    return pd.DataFrame([tuple(row) for row in rows], columns=list(columns))


def class_label(name: str, section: str) -> str:
    return f"{name} - {section}"


def like_pattern(text: str) -> str:
    """Build a ``%text%`` LIKE pattern with wildcard characters escaped (escape char: ``\\``)."""
    escaped = text.strip().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{escaped}%"


@contextmanager
def integrity_guard(message: str) -> Iterator[None]:
    """Translate database integrity errors into a user-friendly ValidationError."""
    try:
        yield
    except IntegrityError as exc:
        raise ValidationError(message) from exc


def new_receipt_no(paid_on: date) -> str:
    """Collision-resistant receipt number, e.g. ``RCPT-20261030-A1B2C3``."""
    return f"RCPT-{paid_on:%Y%m%d}-{secrets.token_hex(3).upper()}"
