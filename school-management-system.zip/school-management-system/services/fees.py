"""Fee structure, payments, dues and receipts.

Amounts are whole currency units. A student's total fee is the sum of the fee
structure of their class; pending = total - everything paid so far.
"""
from __future__ import annotations

from datetime import date
from typing import Any, Optional

import pandas as pd
from sqlalchemy import func, select

from database.models import FeePayment, FeeStructure, SchoolClass, Student
from database.session import session_scope
from services._common import class_label, integrity_guard, new_receipt_no
from utils.clock import today
from utils.config import PAYMENT_METHODS
from utils.validators import ValidationError, coerce_date, optional_text, positive_int, require_text


# --------------------------------------------------------------------------
# Fee structure
# --------------------------------------------------------------------------
def fee_structure(class_id: Optional[int] = None) -> pd.DataFrame:
    stmt = (
        select(
            FeeStructure.id,
            FeeStructure.class_id,
            SchoolClass.name,
            SchoolClass.section,
            FeeStructure.fee_type,
            FeeStructure.amount,
        )
        .join(SchoolClass, SchoolClass.id == FeeStructure.class_id)
        .order_by(SchoolClass.name, SchoolClass.section, FeeStructure.fee_type)
    )
    if class_id is not None:
        stmt = stmt.where(FeeStructure.class_id == class_id)
    with session_scope() as session:
        rows = session.execute(stmt).all()
    data = [(r[0], r[1], class_label(r[2], r[3]), r[4], r[5]) for r in rows]
    return pd.DataFrame(data, columns=["id", "class_id", "class", "fee_type", "amount"])


def set_fee(class_id: int, fee_type: str, amount: Any) -> None:
    """Add a fee line to a class (or update the amount if the type already exists)."""
    fee_type = require_text(fee_type, "Fee type", 60)
    amount_value = positive_int(amount, "Amount")
    with session_scope() as session:
        existing = session.scalar(
            select(FeeStructure).where(
                FeeStructure.class_id == class_id, FeeStructure.fee_type == fee_type
            )
        )
        if existing is not None:
            existing.amount = amount_value
        else:
            session.add(FeeStructure(class_id=class_id, fee_type=fee_type, amount=amount_value))


def update_fee(fee_id: int, fee_type: str, amount: Any) -> None:
    fee_type = require_text(fee_type, "Fee type", 60)
    amount_value = positive_int(amount, "Amount")
    with integrity_guard("This class already has a fee with that name."), session_scope() as s:
        fee = s.get(FeeStructure, fee_id)
        if fee is None:
            raise ValidationError("Fee line not found.")
        fee.fee_type = fee_type
        fee.amount = amount_value


def delete_fee(fee_id: int) -> None:
    with session_scope() as session:
        fee = session.get(FeeStructure, fee_id)
        if fee is None:
            raise ValidationError("Fee line not found.")
        session.delete(fee)


# --------------------------------------------------------------------------
# Dues
# --------------------------------------------------------------------------
def _fee_status(total: int, paid: int) -> str:
    if total == 0:
        return "No fee set"
    if paid >= total:
        return "Paid"
    return "Partial" if paid > 0 else "Unpaid"


def dues_table(class_id: Optional[int] = None, student_id: Optional[int] = None) -> pd.DataFrame:
    """One row per student: total fee, paid, pending and status."""
    stmt = (
        select(Student.id, Student.roll_no, Student.name, Student.class_id,
               SchoolClass.name, SchoolClass.section)
        .join(SchoolClass, SchoolClass.id == Student.class_id)
        .order_by(SchoolClass.name, SchoolClass.section, func.length(Student.roll_no),
                  Student.roll_no)
    )
    if class_id is not None:
        stmt = stmt.where(Student.class_id == class_id)
    if student_id is not None:
        stmt = stmt.where(Student.id == student_id)
    with session_scope() as session:
        students = session.execute(stmt).all()
        totals = dict(
            session.execute(
                select(FeeStructure.class_id, func.sum(FeeStructure.amount)).group_by(
                    FeeStructure.class_id
                )
            ).all()
        )
        paid = dict(
            session.execute(
                select(FeePayment.student_id, func.sum(FeePayment.amount)).group_by(
                    FeePayment.student_id
                )
            ).all()
        )
    rows = []
    for sid, roll, name, cid, class_name, section in students:
        total = int(totals.get(cid, 0) or 0)
        paid_amount = int(paid.get(sid, 0) or 0)
        rows.append(
            (sid, roll, name, class_label(class_name, section), total, paid_amount,
             max(total - paid_amount, 0), _fee_status(total, paid_amount))
        )
    return pd.DataFrame(
        rows,
        columns=["student_id", "roll_no", "name", "class", "total_fee", "paid", "pending",
                 "status"],
    )


def student_fee_summary(student_id: int) -> dict:
    table = dues_table(student_id=student_id)
    if table.empty:
        return {"total": 0, "paid": 0, "pending": 0, "status": "No fee set"}
    row = table.iloc[0]
    return {
        "total": int(row["total_fee"]),
        "paid": int(row["paid"]),
        "pending": int(row["pending"]),
        "status": str(row["status"]),
    }


# --------------------------------------------------------------------------
# Payments and receipts
# --------------------------------------------------------------------------
def record_payment(
    student_id: int,
    amount: Any,
    method: str,
    paid_on: Any,
    note: Optional[str],
    received_by: str,
) -> dict:
    """Record a payment and return its receipt data."""
    amount_value = positive_int(amount, "Amount")
    if method not in PAYMENT_METHODS:
        raise ValidationError("Choose a valid payment method.")
    day = coerce_date(paid_on, "Payment date")
    if day is None or day > today():
        raise ValidationError("Payment date cannot be in the future.")
    note_value = optional_text(note, "Note", 200)

    summary = student_fee_summary(student_id)
    if summary["total"] == 0:
        raise ValidationError("No fee structure is set for this student's class.")
    if amount_value > summary["pending"]:
        raise ValidationError(
            f"Amount exceeds the pending dues ({summary['pending']:,}). "
            "Enter an amount up to the pending balance."
        )

    with integrity_guard("Could not save the payment; please try again."), session_scope() as s:
        payment = FeePayment(
            receipt_no=new_receipt_no(day),
            student_id=student_id,
            amount=amount_value,
            paid_on=day,
            method=method,
            note=note_value,
            received_by=received_by,
        )
        s.add(payment)
        s.flush()
        payment_id = payment.id
    receipt = get_receipt(payment_id)
    if receipt is None:
        raise ValidationError("The payment was saved but its receipt could not be loaded.")
    return receipt


def payments(
    student_id: Optional[int] = None,
    class_id: Optional[int] = None,
    start: Optional[date] = None,
    end: Optional[date] = None,
) -> pd.DataFrame:
    stmt = (
        select(
            FeePayment.id, FeePayment.receipt_no, FeePayment.paid_on, Student.roll_no,
            Student.name, SchoolClass.name, SchoolClass.section, FeePayment.amount,
            FeePayment.method, FeePayment.note, FeePayment.received_by,
        )
        .join(Student, Student.id == FeePayment.student_id)
        .join(SchoolClass, SchoolClass.id == Student.class_id)
        .order_by(FeePayment.paid_on.desc(), FeePayment.id.desc())
    )
    if student_id is not None:
        stmt = stmt.where(FeePayment.student_id == student_id)
    if class_id is not None:
        stmt = stmt.where(Student.class_id == class_id)
    if start is not None:
        stmt = stmt.where(FeePayment.paid_on >= start)
    if end is not None:
        stmt = stmt.where(FeePayment.paid_on <= end)
    with session_scope() as session:
        rows = session.execute(stmt).all()
    data = [
        (r[0], r[1], r[2], r[3], r[4], class_label(r[5], r[6]), r[7], r[8], r[9], r[10])
        for r in rows
    ]
    return pd.DataFrame(
        data,
        columns=["id", "receipt_no", "paid_on", "roll_no", "student", "class", "amount",
                 "method", "note", "received_by"],
    )


def get_receipt(payment_id: int) -> Optional[dict]:
    with session_scope() as session:
        row = session.execute(
            select(
                FeePayment.id, FeePayment.receipt_no, FeePayment.paid_on, FeePayment.amount,
                FeePayment.method, FeePayment.note, FeePayment.received_by, Student.id,
                Student.roll_no, Student.name, Student.guardian_name, SchoolClass.id,
                SchoolClass.name, SchoolClass.section,
            )
            .join(Student, Student.id == FeePayment.student_id)
            .join(SchoolClass, SchoolClass.id == Student.class_id)
            .where(FeePayment.id == payment_id)
        ).first()
        if row is None:
            return None
        total = int(
            session.scalar(
                select(func.coalesce(func.sum(FeeStructure.amount), 0)).where(
                    FeeStructure.class_id == row[11]
                )
            )
            or 0
        )
        paid_to_date = int(
            session.scalar(
                select(func.coalesce(func.sum(FeePayment.amount), 0)).where(
                    FeePayment.student_id == row[7], FeePayment.id <= row[0]
                )
            )
            or 0
        )
    return {
        "payment_id": row[0],
        "receipt_no": row[1],
        "paid_on": row[2],
        "amount": row[3],
        "method": row[4],
        "note": row[5] or "",
        "received_by": row[6] or "",
        "student_id": row[7],
        "roll_no": row[8],
        "student_name": row[9],
        "guardian_name": row[10],
        "class": class_label(row[12], row[13]),
        "total_fee": total,
        "paid_to_date": paid_to_date,
        "balance": max(total - paid_to_date, 0),
    }


def delete_payment(payment_id: int) -> None:
    with session_scope() as session:
        payment = session.get(FeePayment, payment_id)
        if payment is None:
            raise ValidationError("Payment not found.")
        session.delete(payment)
