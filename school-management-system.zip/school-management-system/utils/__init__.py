"""Shared helpers: configuration, validation, security and UI utilities."""
