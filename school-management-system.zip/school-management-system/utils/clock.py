"""Timezone-aware "today" so attendance and fees use the school's local date."""
from __future__ import annotations

from datetime import date, datetime
from zoneinfo import ZoneInfo

from utils.config import TIMEZONE


def today() -> date:
    """Return today's date in the configured ``TIMEZONE`` (falls back to server time)."""
    try:
        return datetime.now(ZoneInfo(TIMEZONE)).date()
    except (KeyError, ValueError):
        return date.today()
