"""Shared Plotly styling so every chart in the app looks the same."""
from __future__ import annotations

from typing import Any

COLORS = {
    "primary": "#1f6f5c",  # matches primaryColor in .streamlit/config.toml
    "accent": "#d98e04",
    "danger": "#b3402f",
    "muted": "#8a9a95",
    "light": "#8fc1b4",
}

# Status colours are always paired with text labels, never colour alone.
STATUS_COLORS = {
    "Present": COLORS["primary"],
    "Late": COLORS["accent"],
    "Leave": COLORS["muted"],
    "Absent": COLORS["danger"],
    "Collected": COLORS["primary"],
    "collected": COLORS["primary"],
    "Pending": COLORS["accent"],
    "pending": COLORS["accent"],
}


def style(fig: Any, height: int = 320) -> Any:
    """Apply the common layout (transparent background, compact margins) to a figure."""
    fig.update_layout(
        template="plotly_white",
        height=height,
        margin=dict(l=8, r=8, t=48, b=8),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        legend_title_text="",
        font=dict(size=13),
    )
    return fig
