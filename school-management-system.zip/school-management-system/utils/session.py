"""Login session handling on top of ``st.session_state``."""
from __future__ import annotations

import time
from typing import Optional

import streamlit as st

from utils.config import SESSION_TIMEOUT_MINUTES

_USER_KEY = "user"
_ACTIVE_KEY = "_last_active"


def login(user: dict) -> None:
    """Store the authenticated user in the session."""
    st.session_state[_USER_KEY] = user
    st.session_state[_ACTIVE_KEY] = time.time()


def logout() -> None:
    """Forget the user and every other piece of session data."""
    for key in list(st.session_state.keys()):
        del st.session_state[key]


def current_user() -> Optional[dict]:
    """Return the signed-in user, or ``None`` (also expires idle sessions)."""
    user = st.session_state.get(_USER_KEY)
    if user is None:
        return None
    idle = time.time() - st.session_state.get(_ACTIVE_KEY, 0)
    if idle > SESSION_TIMEOUT_MINUTES * 60:
        logout()
        st.session_state["_flash"] = ("warning", "Your session expired. Please sign in again.")
        return None
    st.session_state[_ACTIVE_KEY] = time.time()
    return user


def require_role(*roles: str) -> dict:
    """Guard a page: stop rendering unless the user is signed in with an allowed role."""
    user = current_user()
    if user is None:
        st.warning("Please sign in to continue.")
        st.stop()
    if roles and user["role"] not in roles:
        st.error("You do not have permission to view this page.")
        st.stop()
    return user
