"""Helpers for tables: CSV/Excel export and change detection for ``st.data_editor``."""
from __future__ import annotations

import io
import re
from datetime import datetime
from typing import Any

import numpy as np
import pandas as pd
import streamlit as st

_NUMBER_LIKE = re.compile(r"^[+\-]?[\d\s().\-]+$")
EXCEL_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


def _safe_cell(value: Any) -> Any:
    """Neutralise spreadsheet formula injection (cells starting with = + - @)."""
    if not isinstance(value, str) or not value:
        return value
    first = value[0]
    if first in "=@\t\r":
        return "'" + value
    if first in "+-" and not _NUMBER_LIKE.match(value):
        return "'" + value
    return value


def _export_frame(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for column in out.columns:
        series = out[column]
        if pd.api.types.is_numeric_dtype(series) or pd.api.types.is_datetime64_any_dtype(series):
            continue
        out[column] = series.map(_safe_cell)
    out.columns = [str(c).replace("_", " ").title() for c in out.columns]
    return out


def export_buttons(df: pd.DataFrame, filename: str, key: str) -> None:
    """Render CSV and Excel download buttons for ``df`` (``key`` must be unique per page)."""
    if df is None or df.empty:
        return
    export = _export_frame(df)
    csv_bytes = export.to_csv(index=False).encode("utf-8-sig")
    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        export.to_excel(writer, index=False, sheet_name="Data")
    col_csv, col_xlsx, _ = st.columns([1, 1, 4])
    col_csv.download_button(
        "⬇️ CSV", csv_bytes, file_name=f"{filename}.csv", mime="text/csv", key=f"{key}_csv"
    )
    col_xlsx.download_button(
        "⬇️ Excel",
        buffer.getvalue(),
        file_name=f"{filename}.xlsx",
        mime=EXCEL_MIME,
        key=f"{key}_xlsx",
    )


def normalise(value: Any) -> Any:
    """Make cell values comparable (NaN/NaT -> None, timestamps -> date, text stripped)."""
    if value is None or value is pd.NaT:
        return None
    if isinstance(value, float) and np.isnan(value):
        return None
    if isinstance(value, (pd.Timestamp, datetime)):
        return value.date()
    if isinstance(value, np.datetime64):
        return pd.Timestamp(value).date()
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.floating):
        return None if np.isnan(value) else float(value)
    return value


def changed_rows(
    original: pd.DataFrame, edited: pd.DataFrame, columns: list[str], key: str = "id"
) -> list[dict]:
    """Rows of ``edited`` whose ``columns`` differ from ``original`` (matched on ``key``)."""
    base = original.set_index(key)
    changes: list[dict] = []
    for _, row in edited.iterrows():
        row_id = row[key]
        if row_id not in base.index:
            continue
        old = base.loc[row_id]
        if any(normalise(row[c]) != normalise(old[c]) for c in columns):
            change = {key: int(row_id)}
            change.update({c: row[c] for c in columns})
            changes.append(change)
    return changes
