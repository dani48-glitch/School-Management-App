"""Input validation helpers.

Services raise :class:`ValidationError` for anything the user can fix; pages
catch it and show the message with ``st.error``.
"""
from __future__ import annotations

import math
import re
from datetime import date, datetime
from typing import Any, Optional

import numpy as np
import pandas as pd

from utils.clock import today


class ValidationError(ValueError):
    """A problem with user-supplied data that is safe to show to the user."""


_PHONE_RE = re.compile(r"^\+?[0-9][0-9\s\-()]{5,19}$")
_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
_USERNAME_RE = re.compile(r"^[a-z0-9._-]{3,30}$")


def _is_blank(value: Any) -> bool:
    if value is None or value is pd.NaT:
        return True
    if isinstance(value, float) and math.isnan(value):
        return True
    return False


def clean(value: Any) -> str:
    """Return ``value`` as a trimmed string with internal whitespace collapsed."""
    if _is_blank(value):
        return ""
    return " ".join(str(value).split())


def require_text(value: Any, label: str, max_len: int = 100) -> str:
    text = clean(value)
    if not text:
        raise ValidationError(f"{label} is required.")
    if len(text) > max_len:
        raise ValidationError(f"{label} must be at most {max_len} characters.")
    return text


def optional_text(value: Any, label: str, max_len: int = 100) -> Optional[str]:
    text = clean(value)
    if not text:
        return None
    if len(text) > max_len:
        raise ValidationError(f"{label} must be at most {max_len} characters.")
    return text


def validate_phone(value: Any, label: str = "Phone", required: bool = True) -> Optional[str]:
    text = clean(value)
    if not text:
        if required:
            raise ValidationError(f"{label} is required.")
        return None
    if not _PHONE_RE.match(text):
        raise ValidationError(f"{label} must contain 6-20 digits (spaces, +, - and () allowed).")
    return text


def validate_email(value: Any, label: str = "Email", required: bool = False) -> Optional[str]:
    text = clean(value).lower()
    if not text:
        if required:
            raise ValidationError(f"{label} is required.")
        return None
    if len(text) > 120 or not _EMAIL_RE.match(text):
        raise ValidationError(f"{label} is not a valid email address.")
    return text


def validate_username(value: Any) -> str:
    text = clean(value).lower()
    if not _USERNAME_RE.match(text):
        raise ValidationError(
            "Username must be 3-30 characters: lowercase letters, digits, '.', '_' or '-'."
        )
    return text


def coerce_date(value: Any, label: str = "Date", required: bool = True) -> Optional[date]:
    """Convert dates coming from widgets or DataFrames into ``datetime.date``."""
    if _is_blank(value) or (isinstance(value, str) and not value.strip()):
        if required:
            raise ValidationError(f"{label} is required.")
        return None
    if isinstance(value, pd.Timestamp):
        return value.date()
    if isinstance(value, np.datetime64):
        return pd.Timestamp(value).date()
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, str):
        try:
            return date.fromisoformat(value.strip()[:10])
        except ValueError:
            raise ValidationError(f"{label} must be a valid date (YYYY-MM-DD).") from None
    raise ValidationError(f"{label} must be a valid date.")


def validate_dob(value: Any, label: str = "Date of birth") -> date:
    dob = coerce_date(value, label)
    if dob is None:  # coerce_date raises for blanks when required=True
        raise ValidationError(f"{label} is required.")
    current = today()
    age = current.year - dob.year - ((current.month, current.day) < (dob.month, dob.day))
    if dob > current:
        raise ValidationError(f"{label} cannot be in the future.")
    if age < 3 or age > 25:
        raise ValidationError(f"{label} gives an age of {age}; expected between 3 and 25.")
    return dob


def positive_int(value: Any, label: str, maximum: int = 10_000_000) -> int:
    try:
        number = float(value)
    except (TypeError, ValueError):
        raise ValidationError(f"{label} must be a number.") from None
    if math.isnan(number) or math.isinf(number) or number != int(number):
        raise ValidationError(f"{label} must be a whole number.")
    if number <= 0:
        raise ValidationError(f"{label} must be greater than zero.")
    if number > maximum:
        raise ValidationError(f"{label} must not exceed {maximum:,}.")
    return int(number)
