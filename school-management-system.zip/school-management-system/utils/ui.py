"""Small Streamlit UI helpers shared by every page."""
from __future__ import annotations

from typing import Any, Optional, Sequence

import streamlit as st

from utils.config import CURRENCY


def flash(kind: str, message: str) -> None:
    """Queue a message to be shown after the next rerun."""
    st.session_state["_flash"] = (kind, message)


def show_flash() -> None:
    """Display (and clear) a queued message."""
    item = st.session_state.pop("_flash", None)
    if not item:
        return
    kind, message = item
    renderer = {"success": st.success, "error": st.error, "warning": st.warning}.get(kind, st.info)
    renderer(message)


def page_header(title: str, icon: str, caption: Optional[str] = None) -> None:
    st.title(f"{icon} {title}")
    if caption:
        st.caption(caption)


def money(value: Any) -> str:
    """Format a whole-number amount with the configured currency."""
    try:
        return f"{CURRENCY} {int(round(float(value))):,}"
    except (TypeError, ValueError):
        return f"{CURRENCY} 0"


def select_from(
    label: str,
    options: Sequence[tuple[int, str]],
    key: str,
    include_all: bool = False,
    all_label: str = "All",
    container: Any = st,
) -> Optional[int]:
    """Selectbox over ``(id, label)`` pairs; returns the chosen id (or ``None`` for "All")."""
    ids: list[Optional[int]] = [None] if include_all else []
    ids.extend(option_id for option_id, _ in options)
    if not ids:
        container.selectbox(label, ["(nothing available)"], key=key, disabled=True)
        return None
    names = {option_id: text for option_id, text in options}
    return container.selectbox(
        label,
        ids,
        format_func=lambda value: all_label if value is None else names[value],
        key=key,
    )


def scoped_class_options(user: dict) -> list[tuple[int, str]]:
    """Classes the user may work with: everything for admins, own classes for teachers."""
    from services import academics, teachers

    options = academics.class_options()
    if user["role"] == "teacher" and user.get("teacher_id"):
        allowed = set(teachers.teacher_class_ids(user["teacher_id"]))
        options = [option for option in options if option[0] in allowed]
    return options


def editor_key(name: str) -> str:
    """Widget key that changes after a save so ``st.data_editor`` drops stale edits."""
    return f"{name}_v{st.session_state.get(f'_ver_{name}', 0)}"


def reset_editor(name: str) -> None:
    st.session_state[f"_ver_{name}"] = st.session_state.get(f"_ver_{name}", 0) + 1
