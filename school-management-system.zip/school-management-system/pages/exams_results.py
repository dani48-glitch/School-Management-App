"""Exams, marks entry, class results and downloadable report cards."""
from __future__ import annotations

import pandas as pd
import streamlit as st

from services import academics, exams, pdf
from utils import session
from utils.clock import today
from utils.config import SCHOOL_NAME
from utils.tables import export_buttons
from utils.ui import editor_key, flash, page_header, reset_editor, scoped_class_options, select_from
from utils.validators import ValidationError

user = session.require_role("admin", "teacher", "student")
role = user["role"]

page_header("Exams & Results", "📝", "Marks, grades, class rankings and report cards.")


def _exam_options() -> list[tuple[int, str]]:
    table = exams.list_exams()
    return [(int(row.id), f"{row.name} (max {row.max_marks})") for row in table.itertuples()]


def _report_card_button(exam_id: int, student_id: int, key: str) -> None:
    result = exams.student_result(exam_id, student_id)
    if result is None:
        st.info("No marks have been entered for this student in the selected exam.")
        return
    file_name = f"report_card_{result['student']['roll_no']}_{result['exam']['name']}.pdf"
    file_name = file_name.replace(" ", "_")
    st.download_button(
        "📄 Download report card (PDF)",
        data=pdf.report_card_pdf(result, SCHOOL_NAME),
        file_name=file_name,
        mime="application/pdf",
        key=key,
    )


# --------------------------------------------------------------------------
# Admin: manage exams
# --------------------------------------------------------------------------
def _exams_tab() -> None:
    with st.form("add_exam_form", clear_on_submit=True):
        col_a, col_b, col_c = st.columns([2, 1, 1])
        name = col_a.text_input("Exam name *", placeholder="Mid-Term 2026", max_chars=100)
        exam_date = col_b.date_input("Exam date", value=today())
        max_marks = col_c.number_input("Max marks per subject", min_value=1, max_value=1000,
                                       value=100, step=1)
        submitted = st.form_submit_button("Create exam", type="primary")
    if submitted:
        try:
            exams.add_exam(name, exam_date, max_marks)
            flash("success", "Exam created.")
            st.rerun()
        except ValidationError as exc:
            st.error(str(exc))

    table = exams.list_exams()
    if table.empty:
        st.info("No exams yet. Create one above.")
        return
    shown = table.drop(columns=["id"])
    st.dataframe(shown, hide_index=True, use_container_width=True)
    export_buttons(shown, "exams", "exams_export")

    with st.expander("🗑️ Delete an exam"):
        exam_id = select_from("Exam", _exam_options(), key="delete_exam_select")
        st.caption("Deleting an exam also deletes every mark entered for it.")
        confirmed = st.checkbox("Yes, delete this exam and its marks", key="confirm_delete_exam")
        if st.button("Delete exam", disabled=not confirmed or exam_id is None):
            try:
                exams.delete_exam(exam_id)
                flash("success", "Exam deleted.")
                st.rerun()
            except ValidationError as exc:
                st.error(str(exc))


# --------------------------------------------------------------------------
# Admin / teacher: enter marks
# --------------------------------------------------------------------------
def _marks_tab() -> None:
    exam_options = _exam_options()
    class_options = scoped_class_options(user)
    if not exam_options:
        hint = " Create one in the Exams tab." if role == "admin" else ""
        st.info("No exams exist yet." + hint)
        return
    if not class_options:
        st.info("No classes available.")
        return

    col_exam, col_class, col_subject = st.columns(3)
    exam_id = select_from("Exam", exam_options, key="marks_exam", container=col_exam)
    class_id = select_from("Class", class_options, key="marks_class", container=col_class)
    teacher_filter = user.get("teacher_id") if role == "teacher" else None
    subject_options = academics.class_subject_options(class_id, teacher_filter) if class_id else []
    subject_id = select_from("Subject", subject_options, key="marks_subject", container=col_subject)
    if exam_id is None or class_id is None:
        return
    if subject_id is None:
        st.info(
            "No subjects available for you in this class."
            if role == "teacher"
            else "No subjects are assigned to this class yet (see Classes & Subjects)."
        )
        return

    exam = exams.get_exam(exam_id)
    max_marks = exam["max_marks"]
    sheet = exams.marks_sheet(exam_id, class_id, subject_id)
    if sheet.empty:
        st.info("This class has no students yet.")
        return

    st.caption(f"Enter marks out of {max_marks}. Leave a cell empty for 'not graded'.")
    name = f"marks_{exam_id}_{class_id}_{subject_id}"
    edited = st.data_editor(
        sheet,
        key=editor_key(name),
        hide_index=True,
        use_container_width=True,
        num_rows="fixed",
        disabled=["student_id", "roll_no", "name"],
        column_order=["roll_no", "name", "marks"],
        column_config={
            "roll_no": st.column_config.TextColumn("Roll no."),
            "name": st.column_config.TextColumn("Name"),
            "marks": st.column_config.NumberColumn(
                f"Marks (0-{max_marks})", min_value=0, max_value=max_marks, step=0.5
            ),
        },
    )

    preview = edited[["roll_no", "name", "marks"]].copy()
    preview["percentage"] = (preview["marks"] / max_marks * 100).round(1)
    preview["grade"] = preview["percentage"].map(lambda p: exams.grade_for(p)[0])
    with st.expander("Preview percentage and grade"):
        st.dataframe(preview, hide_index=True, use_container_width=True)

    if st.button("💾 Save marks", type="primary"):
        marks = {
            int(row.student_id): (None if pd.isna(row.marks) else float(row.marks))
            for row in edited.itertuples()
        }
        try:
            saved = exams.save_marks(exam_id, class_id, subject_id, marks, teacher_filter)
            reset_editor(name)
            flash("success", f"Marks saved for {saved} student(s).")
            st.rerun()
        except ValidationError as exc:
            st.error(str(exc))


# --------------------------------------------------------------------------
# Admin / teacher: class results and report cards
# --------------------------------------------------------------------------
def _results_tab() -> None:
    exam_options = _exam_options()
    class_options = scoped_class_options(user)
    if not exam_options or not class_options:
        st.info("Create an exam and a class first.")
        return
    col_exam, col_class = st.columns(2)
    exam_id = select_from("Exam", exam_options, key="results_exam", container=col_exam)
    class_id = select_from("Class", class_options, key="results_class", container=col_class)
    if exam_id is None or class_id is None:
        return

    results = exams.class_results(exam_id, class_id)
    if results.empty:
        st.info("This class has no students yet.")
        return
    shown = results.drop(columns=["student_id"])
    st.dataframe(
        shown,
        hide_index=True,
        use_container_width=True,
        column_config={
            "roll_no": "Roll no.",
            "name": "Name",
            "subjects": "Subjects graded",
            "total": st.column_config.NumberColumn("Total", format="%.1f"),
            "max_total": st.column_config.NumberColumn("Out of", format="%.0f"),
            "percentage": st.column_config.ProgressColumn(
                "Percentage", min_value=0, max_value=100, format="%.1f%%"
            ),
        },
    )
    export_buttons(shown, "class_results", "results_export")

    graded = results[results["subjects"] > 0]
    if graded.empty:
        return
    st.subheader("Report card")
    labels = {
        int(row.student_id): f"{row.roll_no} - {row.name}" for row in graded.itertuples()
    }
    student_id = select_from("Student", list(labels.items()), key="report_student")
    if student_id is not None:
        _report_card_button(exam_id, student_id, key="report_card_staff")


# --------------------------------------------------------------------------
# Student: own results
# --------------------------------------------------------------------------
def _my_results() -> None:
    student_id = user.get("student_id")
    if not student_id:
        st.warning("Your account is not linked to a student record. Ask the administrator.")
        return
    mine = exams.student_exams(student_id)
    if mine.empty:
        st.info("No results have been published for you yet.")
        return
    options = [(int(row.id), row.name) for row in mine.itertuples()]
    exam_id = select_from("Exam", options, key="my_exam")
    result = exams.student_result(exam_id, student_id) if exam_id else None
    if result is None:
        st.info("No marks found for this exam.")
        return

    cols = st.columns(4)
    cols[0].metric("Total", f"{result['total']:.1f} / {result['max_total']}")
    cols[1].metric("Percentage", f"{result['percentage']:.1f}%")
    cols[2].metric("Grade", f"{result['grade']} ({result['status']})")
    cols[3].metric(
        "Class rank",
        f"{result['rank']} of {result['class_size']}" if result["rank"] else "-",
    )
    subjects = result["subjects"].rename(
        columns={"subject": "Subject", "marks": "Marks", "max_marks": "Out of",
                 "percentage": "%", "grade": "Grade"}
    )
    st.dataframe(subjects, hide_index=True, use_container_width=True)
    export_buttons(subjects, "my_results", "my_results_export")
    _report_card_button(exam_id, student_id, key="report_card_student")


# --------------------------------------------------------------------------
# Layout
# --------------------------------------------------------------------------
if role == "student":
    _my_results()
elif role == "admin":
    exams_tab, marks_tab, results_tab = st.tabs(
        ["🗂️ Exams", "✏️ Enter marks", "🏆 Results & report cards"]
    )
    with exams_tab:
        _exams_tab()
    with marks_tab:
        _marks_tab()
    with results_tab:
        _results_tab()
else:
    marks_tab, results_tab = st.tabs(["✏️ Enter marks", "🏆 Results & report cards"])
    with marks_tab:
        _marks_tab()
    with results_tab:
        _results_tab()
