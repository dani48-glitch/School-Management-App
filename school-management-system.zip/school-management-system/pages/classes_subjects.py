"""Classes, subjects, and who teaches what (admin only)."""
from __future__ import annotations

import streamlit as st

from services import academics, teachers
from utils import session
from utils.tables import export_buttons
from utils.ui import flash, page_header, select_from
from utils.validators import ValidationError

user = session.require_role("admin")

page_header("Classes & Subjects", "🏫", "Set up classes, subjects and teacher assignments.")


def _classes_tab() -> None:
    with st.form("add_class_form", clear_on_submit=True):
        col_a, col_b = st.columns(2)
        name = col_a.text_input("Class name *", placeholder="Grade 6", max_chars=50)
        section = col_b.text_input("Section *", placeholder="A", max_chars=10)
        submitted = st.form_submit_button("Add class", type="primary")
    if submitted:
        try:
            academics.add_class(name, section)
            flash("success", "Class added.")
            st.rerun()
        except ValidationError as exc:
            st.error(str(exc))

    table = academics.list_classes()
    if table.empty:
        st.info("No classes yet. Add the first one above.")
        return
    shown = table.drop(columns=["id"]).rename(columns={"name": "class"})
    st.dataframe(shown, hide_index=True, use_container_width=True)
    export_buttons(shown, "classes", "classes_export")

    with st.expander("🗑️ Delete a class"):
        class_id = select_from("Class", academics.class_options(), key="delete_class_select")
        st.caption("A class can only be deleted when it has no students.")
        confirmed = st.checkbox("Yes, delete this class", key="confirm_delete_class")
        if st.button("Delete class", disabled=not confirmed or class_id is None):
            try:
                academics.delete_class(class_id)
                flash("success", "Class deleted.")
                st.rerun()
            except ValidationError as exc:
                st.error(str(exc))


def _subjects_tab() -> None:
    with st.form("add_subject_form", clear_on_submit=True):
        col_a, col_b = st.columns([2, 1])
        name = col_a.text_input("Subject name *", placeholder="Mathematics", max_chars=80)
        code = col_b.text_input("Code", placeholder="MATH", max_chars=20)
        submitted = st.form_submit_button("Add subject", type="primary")
    if submitted:
        try:
            academics.add_subject(name, code)
            flash("success", "Subject added.")
            st.rerun()
        except ValidationError as exc:
            st.error(str(exc))

    table = academics.list_subjects()
    if table.empty:
        st.info("No subjects yet.")
        return
    shown = table.drop(columns=["id"])
    st.dataframe(shown, hide_index=True, use_container_width=True)
    export_buttons(shown, "subjects", "subjects_export")

    with st.expander("🗑️ Delete a subject"):
        subject_id = select_from(
            "Subject", academics.subject_options(), key="delete_subject_select"
        )
        st.caption("Also removes the subject from every class, timetable and exam result.")
        confirmed = st.checkbox("Yes, delete this subject", key="confirm_delete_subject")
        if st.button("Delete subject", disabled=not confirmed or subject_id is None):
            try:
                academics.delete_subject(subject_id)
                flash("success", "Subject deleted.")
                st.rerun()
            except ValidationError as exc:
                st.error(str(exc))


def _assign_tab() -> None:
    class_options = academics.class_options()
    subject_options = academics.subject_options()
    if not class_options or not subject_options:
        st.info("Create at least one class and one subject first.")
        return

    class_id = select_from("Class", class_options, key="assign_class")
    with st.form("assign_form"):
        col_a, col_b = st.columns(2)
        subject_id = select_from("Subject", subject_options, key="assign_subject", container=col_a)
        teacher_id = select_from(
            "Teacher",
            teachers.teacher_options(),
            key="assign_teacher",
            include_all=True,
            all_label="(unassigned)",
            container=col_b,
        )
        submitted = st.form_submit_button("Assign / update", type="primary")
    if submitted:
        try:
            academics.assign_subject(class_id, subject_id, teacher_id)
            flash("success", "Assignment saved.")
            st.rerun()
        except ValidationError as exc:
            st.error(str(exc))

    table = academics.class_subject_table(class_id=class_id)
    if table.empty:
        st.info("No subjects are assigned to this class yet.")
        return
    shown = table[["class", "subject", "teacher"]]
    st.dataframe(shown, hide_index=True, use_container_width=True)
    export_buttons(shown, "class_subjects", "assign_export")

    with st.expander("➖ Remove a subject from this class"):
        labels = {int(row.id): str(row.subject) for row in table.itertuples()}
        assignment_id = select_from("Subject", list(labels.items()), key="remove_assignment")
        if st.button("Remove from class", disabled=assignment_id is None):
            try:
                academics.remove_assignment(assignment_id)
                flash("success", "Subject removed from the class.")
                st.rerun()
            except ValidationError as exc:
                st.error(str(exc))


classes_tab, subjects_tab, assign_tab = st.tabs(
    ["🏫 Classes", "📘 Subjects", "👩‍🏫 Assign teachers"]
)
with classes_tab:
    _classes_tab()
with subjects_tab:
    _subjects_tab()
with assign_tab:
    _assign_tab()
