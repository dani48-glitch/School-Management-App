"""Attendance: daily marking, monthly reports and per-student percentages."""
from __future__ import annotations

import calendar
from datetime import timedelta

import plotly.express as px
import streamlit as st

from services import attendance, students
from utils import session
from utils.charts import COLORS, STATUS_COLORS, style
from utils.clock import today
from utils.config import ATTENDANCE_STATUSES, LOW_ATTENDANCE_PERCENT
from utils.tables import export_buttons
from utils.ui import editor_key, flash, page_header, reset_editor, scoped_class_options, select_from
from utils.validators import ValidationError

user = session.require_role("admin", "teacher", "student")
page_header("Attendance", "🗓️", "Attendance % = (Present + Late) / days marked.")


# --------------------------------------------------------------------------
# Staff views
# --------------------------------------------------------------------------
def _mark_tab(class_options: list[tuple[int, str]]) -> None:
    col_class, col_date = st.columns(2)
    class_id = select_from("Class", class_options, key="mark_class", container=col_class)
    day = col_date.date_input("Date", value=today(), max_value=today(), key="mark_date")
    if class_id is None:
        return

    sheet, already_marked = attendance.attendance_sheet(class_id, day)
    if sheet.empty:
        st.info("This class has no students yet.")
        return
    if already_marked:
        st.info(f"Attendance for {day:%d %b %Y} was already saved. Edit and save to update it.")

    edited = st.data_editor(
        sheet,
        key=editor_key(f"attendance_{class_id}_{day.isoformat()}"),
        hide_index=True,
        use_container_width=True,
        num_rows="fixed",
        disabled=["student_id", "roll_no", "name"],
        column_order=["roll_no", "name", "status"],
        column_config={
            "roll_no": st.column_config.TextColumn("Roll no."),
            "name": st.column_config.TextColumn("Name"),
            "status": st.column_config.SelectboxColumn(
                "Status", options=ATTENDANCE_STATUSES, required=True
            ),
        },
    )

    counts = edited["status"].value_counts()
    cols = st.columns(len(ATTENDANCE_STATUSES))
    for column, status in zip(cols, ATTENDANCE_STATUSES):
        column.metric(status, int(counts.get(status, 0)))

    if st.button("💾 Save attendance", type="primary"):
        statuses = {int(row.student_id): str(row.status) for row in edited.itertuples()}
        try:
            saved = attendance.save_attendance(class_id, day, statuses)
            reset_editor(f"attendance_{class_id}_{day.isoformat()}")
            flash("success", f"Attendance saved for {saved} student(s) on {day:%d %b %Y}.")
            st.rerun()
        except ValidationError as exc:
            st.error(str(exc))


def _monthly_tab(class_options: list[tuple[int, str]]) -> None:
    current = today()
    col_class, col_year, col_month = st.columns([2, 1, 1])
    class_id = select_from("Class", class_options, key="report_class", container=col_class)
    years = list(range(current.year, current.year - 4, -1))
    year = col_year.selectbox("Year", years, key="report_year")
    month = col_month.selectbox(
        "Month",
        list(range(1, 13)),
        index=current.month - 1,
        format_func=lambda m: calendar.month_name[m],
        key="report_month",
    )
    if class_id is None:
        return

    report = attendance.monthly_report(class_id, year, month)
    if report.empty:
        st.info("This class has no students yet.")
        return
    if report["marked_days"].sum() == 0:
        st.info("No attendance was marked for this class in the selected month.")
        return

    average = report["attendance_pct"].dropna().mean()
    low = report[report["attendance_pct"] < LOW_ATTENDANCE_PERCENT]
    cols = st.columns(3)
    cols[0].metric("Class average", f"{average:.1f}%")
    cols[1].metric("Days marked", int(report["marked_days"].max()))
    cols[2].metric(f"Below {LOW_ATTENDANCE_PERCENT}%", len(low))

    st.dataframe(
        report,
        hide_index=True,
        use_container_width=True,
        column_config={
            "roll_no": "Roll no.",
            "name": "Name",
            "present": "Present",
            "absent": "Absent",
            "late": "Late",
            "leave": "Leave",
            "marked_days": "Days marked",
            "attendance_pct": st.column_config.ProgressColumn(
                "Attendance %", min_value=0, max_value=100, format="%.1f%%"
            ),
        },
    )
    export_buttons(report, f"attendance_{year}_{month:02d}", "monthly_report")

    chart_data = report.dropna(subset=["attendance_pct"])
    fig = px.bar(
        chart_data,
        x="name",
        y="attendance_pct",
        title="Attendance % per student",
        color_discrete_sequence=[COLORS["primary"]],
    )
    fig.add_hline(y=LOW_ATTENDANCE_PERCENT, line_dash="dash", line_color=COLORS["danger"],
                  annotation_text=f"{LOW_ATTENDANCE_PERCENT}% target")
    fig.update_yaxes(range=[0, 100], title=None)
    fig.update_xaxes(title=None)
    st.plotly_chart(style(fig), use_container_width=True)

    with st.expander("📅 Day-by-day grid (P = present, A = absent, L = late, LV = leave)"):
        matrix = attendance.monthly_matrix(class_id, year, month)
        st.dataframe(matrix, hide_index=True, use_container_width=True)
        export_buttons(matrix, f"attendance_grid_{year}_{month:02d}", "monthly_grid")


def _student_tab(class_options: list[tuple[int, str]]) -> None:
    col_class, col_student = st.columns(2)
    class_id = select_from("Class", class_options, key="lookup_class", container=col_class)
    if class_id is None:
        return
    student_id = select_from(
        "Student", students.student_options(class_id), key="lookup_student", container=col_student
    )
    if student_id is None:
        st.info("This class has no students yet.")
        return
    _student_report(student_id, key_prefix="lookup")


# --------------------------------------------------------------------------
# Shared by staff lookup and the student's own page
# --------------------------------------------------------------------------
def _student_report(student_id: int, key_prefix: str) -> None:
    col_from, col_to = st.columns(2)
    start = col_from.date_input(
        "From", value=today() - timedelta(days=90), max_value=today(), key=f"{key_prefix}_from"
    )
    end = col_to.date_input("To", value=today(), max_value=today(), key=f"{key_prefix}_to")
    if start > end:
        st.error("The start date must not be after the end date.")
        return

    summary = attendance.student_summary(student_id, start, end)
    if summary["marked"] == 0:
        st.info("No attendance has been recorded for this period.")
        return

    pct = summary["percentage"]
    cols = st.columns(5)
    cols[0].metric(
        "Attendance %",
        f"{pct:.1f}%",
        delta="Below target" if pct < LOW_ATTENDANCE_PERCENT else None,
        delta_color="inverse",
    )
    for column, status in zip(cols[1:], ATTENDANCE_STATUSES):
        column.metric(status, summary["counts"][status])

    donut = px.pie(
        names=list(summary["counts"].keys()),
        values=list(summary["counts"].values()),
        hole=0.55,
        color=list(summary["counts"].keys()),
        color_discrete_map=STATUS_COLORS,
    )
    donut.update_traces(textinfo="label+value")
    st.plotly_chart(style(donut, 280), use_container_width=True)

    history = attendance.student_history(student_id, start, end)
    st.dataframe(history, hide_index=True, use_container_width=True)
    export_buttons(history, "attendance_history", f"{key_prefix}_history")


# --------------------------------------------------------------------------
# Page layout
# --------------------------------------------------------------------------
if user["role"] == "student":
    student_id = user.get("student_id")
    if not student_id:
        st.warning("Your account is not linked to a student record. Ask the administrator.")
        st.stop()
    _student_report(student_id, key_prefix="mine")
else:
    options = scoped_class_options(user)
    if not options:
        st.info("No classes available. Teachers see the classes they are assigned to.")
        st.stop()
    mark_tab, month_tab, lookup_tab = st.tabs(
        ["✅ Mark attendance", "📊 Monthly report", "🔎 Student lookup"]
    )
    with mark_tab:
        _mark_tab(options)
    with month_tab:
        _monthly_tab(options)
    with lookup_tab:
        _student_tab(options)
