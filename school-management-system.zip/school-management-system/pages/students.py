"""Students: search, add, edit in place and delete (admin); read-only list for teachers."""
from __future__ import annotations

from datetime import date

import pandas as pd
import streamlit as st

from services import students
from utils import session
from utils.clock import today
from utils.tables import changed_rows, export_buttons
from utils.ui import editor_key, flash, page_header, reset_editor, scoped_class_options, select_from
from utils.validators import ValidationError

user = session.require_role("admin", "teacher")
is_admin = user["role"] == "admin"

page_header(
    "Students",
    "🎓",
    "Add, edit and manage student records." if is_admin else "Students in your classes.",
)

class_options = scoped_class_options(user)
if not is_admin and not class_options:
    st.info("You have no classes assigned yet. Ask the administrator to assign you to a class.")
    st.stop()

EDITABLE = ["roll_no", "name", "class", "dob", "guardian_name", "phone", "address"]


def _student_table(search: str, class_id: int | None) -> pd.DataFrame:
    """Students visible to the current user (teachers only see their own classes)."""
    allowed = None if is_admin else [option[0] for option in class_options]
    return students.list_students(search=search, class_id=class_id, class_ids=allowed)


def _list_tab() -> None:
    col_search, col_class = st.columns([2, 1])
    search = col_search.text_input(
        "🔎 Search", placeholder="Name, roll no., guardian or phone", key="student_search"
    )
    class_id = select_from(
        "Class", class_options, key="student_class_filter", include_all=True, container=col_class
    )
    table = _student_table(search, class_id)
    st.caption(f"{len(table)} student(s)")
    if table.empty:
        st.info("No students match your search.")
        return

    export_buttons(table.drop(columns=["id", "class_id"]), "students", "students_export")

    if not is_admin:
        st.dataframe(
            table.drop(columns=["id", "class_id"]),
            hide_index=True,
            use_container_width=True,
            column_config={"dob": st.column_config.DateColumn("Date of birth")},
        )
        return

    st.caption("Double-click a cell to edit. Tick **Delete** to remove a student.")
    label_to_id = {label: class_pk for class_pk, label in class_options}
    view = table.copy()
    view["delete"] = False
    edited = st.data_editor(
        view,
        key=editor_key("students"),
        hide_index=True,
        use_container_width=True,
        num_rows="fixed",
        column_order=EDITABLE + ["delete"],
        column_config={
            "roll_no": st.column_config.TextColumn("Roll no.", required=True, max_chars=20),
            "name": st.column_config.TextColumn("Name", required=True, max_chars=100),
            "class": st.column_config.SelectboxColumn(
                "Class", options=list(label_to_id), required=True
            ),
            "dob": st.column_config.DateColumn("Date of birth", required=True, format="YYYY-MM-DD"),
            "guardian_name": st.column_config.TextColumn("Guardian", required=True, max_chars=100),
            "phone": st.column_config.TextColumn("Phone", required=True, max_chars=30),
            "address": st.column_config.TextColumn("Address", required=True, max_chars=300),
            "delete": st.column_config.CheckboxColumn("Delete", default=False),
        },
    )

    to_delete = edited.loc[edited["delete"], "id"].astype(int).tolist()
    pending_changes = [
        change for change in changed_rows(view, edited, EDITABLE) if change["id"] not in to_delete
    ]

    save_col, delete_col, _ = st.columns([1, 1.4, 3])
    if save_col.button("💾 Save changes", type="primary", disabled=not pending_changes):
        errors, saved = [], 0
        for change in pending_changes:
            row_id = change.pop("id")
            change["class_id"] = label_to_id.get(change.pop("class"))
            try:
                students.update_student(row_id, **change)
                saved += 1
            except ValidationError as exc:
                errors.append(f"{change.get('name') or 'Student'}: {exc}")
        if errors:
            st.error("Some rows could not be saved:\n\n- " + "\n- ".join(errors))
            if saved:
                st.success(f"{saved} row(s) saved.")
        else:
            reset_editor("students")
            flash("success", f"{saved} student record(s) updated.")
            st.rerun()

    if to_delete:
        st.warning(
            f"{len(to_delete)} student(s) selected. Deleting also removes their attendance, "
            "results, fee payments and login accounts."
        )
        confirmed = st.checkbox("Yes, permanently delete the selected students", key="confirm_del")
        if delete_col.button("🗑️ Delete selected", disabled=not confirmed):
            try:
                for student_id in to_delete:
                    students.delete_student(student_id)
                reset_editor("students")
                flash("success", f"{len(to_delete)} student(s) deleted.")
                st.rerun()
            except ValidationError as exc:
                st.error(str(exc))


def _add_tab() -> None:
    if not class_options:
        st.info("Create a class first (Classes & Subjects page), then add students.")
        return
    current = today()
    with st.form("add_student_form", clear_on_submit=True):
        col_a, col_b = st.columns(2)
        name = col_a.text_input("Full name *", max_chars=100)
        roll_no = col_b.text_input("Roll no. *", max_chars=20)
        class_id = select_from("Class & section *", class_options, key="add_student_class",
                               container=col_a)
        dob = col_b.date_input(
            "Date of birth *",
            value=date(current.year - 10, 1, 1),
            min_value=date(current.year - 25, 1, 1),
            max_value=current,
        )
        guardian = col_a.text_input("Guardian name *", max_chars=100)
        phone = col_b.text_input("Phone *", max_chars=30, placeholder="0300-1234567")
        address = st.text_area("Address *", max_chars=300, height=80)
        submitted = st.form_submit_button("Add student", type="primary")
    if submitted:
        try:
            students.add_student(roll_no, name, class_id, dob, guardian, phone, address)
            flash("success", f"{name.strip()} was added.")
            st.rerun()
        except ValidationError as exc:
            st.error(str(exc))
    st.caption(
        "To give a student or parent a login, open **User Accounts** and create a student account."
    )


if is_admin:
    list_tab, add_tab = st.tabs(["📋 Student list", "➕ Add student"])
    with list_tab:
        _list_tab()
    with add_tab:
        _add_tab()
else:
    _list_tab()
