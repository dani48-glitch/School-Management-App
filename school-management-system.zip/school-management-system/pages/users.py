"""User accounts: create logins for teachers and students, reset passwords, disable accounts."""
from __future__ import annotations

import streamlit as st

from services import auth, students, teachers
from utils import session
from utils.tables import export_buttons
from utils.ui import flash, page_header, select_from
from utils.validators import ValidationError

user = session.require_role("admin")

page_header("User Accounts", "🔐", "Logins for administrators, teachers and students/parents.")

ROLE_LABELS = {"admin": "Administrator", "teacher": "Teacher", "student": "Student / Parent"}


def _accounts_tab() -> None:
    table = auth.list_users()
    shown = table.drop(columns=["id"])
    st.dataframe(shown, hide_index=True, use_container_width=True)
    export_buttons(shown, "user_accounts", "users_export")

    st.subheader("Manage an account")
    options = [(int(row.id), f"{row.username} ({row.role})") for row in table.itertuples()]
    user_id = select_from("Account", options, key="manage_user")
    if user_id is None:
        return
    selected = table[table["id"] == user_id].iloc[0]

    col_reset, col_state = st.columns(2)
    with col_reset:
        with st.form("reset_password_form", clear_on_submit=True):
            new_password = st.text_input(
                "New password", type="password", autocomplete="new-password"
            )
            reset = st.form_submit_button("Reset password")
        st.caption("At least 8 characters with a letter and a digit.")
        if reset:
            try:
                auth.reset_password(user_id, new_password)
                flash("success", f"Password reset for {selected['username']}.")
                st.rerun()
            except ValidationError as exc:
                st.error(str(exc))

    with col_state:
        is_active = bool(selected["active"])
        st.markdown(f"Status: **{'Active' if is_active else 'Disabled'}**")
        if st.button("Disable account" if is_active else "Enable account"):
            try:
                auth.set_active(user_id, not is_active, user["id"])
                flash("success", "Account updated.")
                st.rerun()
            except ValidationError as exc:
                st.error(str(exc))

        confirmed = st.checkbox("Yes, permanently delete this account", key="confirm_delete_user")
        if st.button("🗑️ Delete account", disabled=not confirmed):
            try:
                auth.delete_user(user_id, user["id"])
                flash("success", "Account deleted.")
                st.rerun()
            except ValidationError as exc:
                st.error(str(exc))


def _create_tab() -> None:
    role = st.selectbox("Role", list(ROLE_LABELS), format_func=ROLE_LABELS.get, key="new_role")

    linked_id = None
    full_name = ""
    if role == "student":
        options = students.student_options()
        if not options:
            st.info("Add a student first.")
            return
        linked_id = select_from("Student", options, key="new_student")
        info = students.get_student(linked_id) if linked_id else None
        full_name = info["name"] if info else ""
    elif role == "teacher":
        options = teachers.teacher_options()
        if not options:
            st.info("Add a teacher first.")
            return
        linked_id = select_from("Teacher", options, key="new_teacher")
        info = teachers.get_teacher(linked_id) if linked_id else None
        full_name = info["name"] if info else ""

    with st.form("create_user_form", clear_on_submit=True):
        username = st.text_input(
            "Username *", max_chars=30, help="Lowercase letters, digits, '.', '_' or '-'."
        )
        if role == "admin":
            full_name = st.text_input("Full name *", max_chars=100)
        else:
            st.text_input("Full name", value=full_name, disabled=True)
        col_a, col_b = st.columns(2)
        password = col_a.text_input("Password *", type="password", autocomplete="new-password")
        confirm = col_b.text_input("Confirm password *", type="password",
                                   autocomplete="new-password")
        submitted = st.form_submit_button("Create account", type="primary")
    st.caption("Passwords need at least 8 characters, including a letter and a digit.")

    if submitted:
        try:
            if password != confirm:
                raise ValidationError("The passwords do not match.")
            auth.create_user(
                username,
                password,
                role,
                full_name,
                student_id=linked_id if role == "student" else None,
                teacher_id=linked_id if role == "teacher" else None,
            )
            flash("success", f"Account '{username.strip().lower()}' created.")
            st.rerun()
        except ValidationError as exc:
            st.error(str(exc))


accounts_tab, create_tab = st.tabs(["👥 Accounts", "➕ Create account"])
with accounts_tab:
    _accounts_tab()
with create_tab:
    _create_tab()
