"""Dashboard: school-wide numbers for staff, a personal overview for students."""
from __future__ import annotations

import pandas as pd
import plotly.express as px
import streamlit as st

from services import (
    academics,
    announcements,
    dashboard,
    exams,
    students,
    teachers,
    timetable,
)
from utils import session
from utils.charts import COLORS, STATUS_COLORS, style
from utils.clock import today
from utils.config import DAYS, LOW_ATTENDANCE_PERCENT, SCHOOL_NAME
from utils.ui import money, page_header

user = session.require_role("admin", "teacher", "student")


def _pct(value) -> str:
    return "Not marked yet" if value is None else f"{value:.1f}%"


def _announcements_panel() -> None:
    latest = announcements.list_announcements(limit=3)
    st.subheader("📢 Latest announcements")
    if not latest:
        st.caption("No announcements yet.")
        return
    for item in latest:
        with st.container(border=True):
            st.markdown(f"**{item['title']}**")
            st.caption(f"{item['posted_by']} · {item['created_at']:%d %b %Y}")
            st.markdown(item["body"])


def _attendance_trend_chart() -> None:
    trend = dashboard.attendance_trend(14)
    if trend.empty:
        st.info("No attendance has been marked in the last 14 days.")
        return
    fig = px.line(
        trend,
        x="date",
        y="attendance_pct",
        markers=True,
        title="School attendance - last 14 days (%)",
        color_discrete_sequence=[COLORS["primary"]],
    )
    fig.update_yaxes(range=[0, 100], title=None)
    fig.update_xaxes(title=None)
    st.plotly_chart(style(fig), use_container_width=True)


def _students_per_class_chart(class_ids: list[int] | None = None) -> None:
    classes = academics.list_classes()
    if class_ids is not None:
        classes = classes[classes["id"].isin(class_ids)]
    if classes.empty:
        st.info("No classes yet.")
        return
    classes = classes.assign(label=classes["name"] + " - " + classes["section"])
    fig = px.bar(
        classes,
        x="label",
        y="students",
        text="students",
        title="Students per class",
        color_discrete_sequence=[COLORS["primary"]],
    )
    fig.update_xaxes(title=None)
    fig.update_yaxes(title=None)
    st.plotly_chart(style(fig), use_container_width=True)


def _fees_charts(metrics: dict) -> None:
    left, right = st.columns(2)
    if metrics["fees_expected"] > 0:
        pie = px.pie(
            names=["Collected", "Pending"],
            values=[metrics["fees_collected"], metrics["fees_pending"]],
            hole=0.55,
            title="Fees collected vs pending",
            color=["Collected", "Pending"],
            color_discrete_map=STATUS_COLORS,
        )
        pie.update_traces(textinfo="label+percent")
        left.plotly_chart(style(pie), use_container_width=True)
    else:
        left.info("No fee structure has been set up yet.")

    by_class = dashboard.fees_by_class()
    if by_class.empty:
        right.info("No fee data to chart.")
    else:
        bars = px.bar(
            by_class,
            x="class",
            y=["collected", "pending"],
            barmode="stack",
            title="Fees by class",
            color_discrete_map=STATUS_COLORS,
        )
        bars.update_xaxes(title=None)
        bars.update_yaxes(title=None)
        right.plotly_chart(style(bars), use_container_width=True)


def _subject_chart() -> None:
    exam_id = dashboard.latest_exam_id()
    if exam_id is None:
        return
    averages = dashboard.subject_averages(exam_id)
    exam = exams.get_exam(exam_id)
    if averages.empty or exam is None:
        return
    fig = px.bar(
        averages,
        x="subject",
        y="average_pct",
        text="average_pct",
        title=f"Average score by subject - {exam['name']} (%)",
        color_discrete_sequence=[COLORS["primary"]],
    )
    fig.update_yaxes(range=[0, 100], title=None)
    fig.update_xaxes(title=None)
    st.plotly_chart(style(fig), use_container_width=True)


def _today_schedule(grid: pd.DataFrame) -> None:
    weekday = today().weekday()
    st.subheader("⏰ Today's schedule")
    if weekday >= len(DAYS):
        st.caption("No classes today (weekend).")
        return
    schedule = timetable.day_schedule(grid, weekday)
    schedule = schedule[schedule["lesson"] != ""]
    if schedule.empty:
        st.caption("Nothing scheduled today.")
    else:
        st.dataframe(schedule, hide_index=True, use_container_width=True)


# --------------------------------------------------------------------------
# Admin
# --------------------------------------------------------------------------
def admin_dashboard() -> None:
    metrics = dashboard.admin_metrics()
    cols = st.columns(4)
    cols[0].metric("Students", metrics["students"])
    cols[1].metric("Teachers", metrics["teachers"])
    cols[2].metric("Classes", metrics["classes"])
    cols[3].metric("Attendance today", _pct(metrics["attendance_pct"]))

    cols = st.columns(3)
    cols[0].metric("Fees expected", money(metrics["fees_expected"]))
    cols[1].metric("Fees collected", money(metrics["fees_collected"]))
    cols[2].metric("Fees pending", money(metrics["fees_pending"]))

    _fees_charts(metrics)
    left, right = st.columns(2)
    with left:
        _attendance_trend_chart()
    with right:
        _students_per_class_chart()
    _subject_chart()
    _announcements_panel()


# --------------------------------------------------------------------------
# Teacher
# --------------------------------------------------------------------------
def teacher_dashboard() -> None:
    teacher_id = user.get("teacher_id")
    if not teacher_id:
        st.warning("Your account is not linked to a teacher profile. Ask the administrator.")
        return
    mine = dashboard.teacher_metrics(teacher_id)
    school = dashboard.admin_metrics()
    cols = st.columns(4)
    cols[0].metric("My classes", mine["classes"])
    cols[1].metric("My subjects", mine["subjects"])
    cols[2].metric("My students", mine["students"])
    cols[3].metric("School attendance today", _pct(school["attendance_pct"]))

    class_ids = teachers.teacher_class_ids(teacher_id)
    left, right = st.columns(2)
    with left:
        _attendance_trend_chart()
    with right:
        _students_per_class_chart(class_ids)

    _today_schedule(timetable.teacher_grid(teacher_id))
    _announcements_panel()


# --------------------------------------------------------------------------
# Student / parent
# --------------------------------------------------------------------------
def student_dashboard() -> None:
    student_id = user.get("student_id")
    info = students.get_student(student_id) if student_id else None
    if info is None:
        st.warning("Your account is not linked to a student record. Ask the administrator.")
        return
    st.markdown(f"**{info['name']}** · {info['class']} · Roll no. {info['roll_no']}")
    overview = dashboard.student_metrics(student_id)
    attendance_summary = overview["attendance"]
    result = overview["latest_result"]
    fee = overview["fees"]

    cols = st.columns(3)
    pct = attendance_summary["percentage"]
    cols[0].metric(
        "Attendance",
        _pct(pct),
        delta="Below target" if pct is not None and pct < LOW_ATTENDANCE_PERCENT else None,
        delta_color="inverse",
    )
    if result:
        cols[1].metric(
            f"Latest result - {result['exam']['name']}",
            f"{result['percentage']:.1f}%",
            delta=f"Grade {result['grade']}",
            delta_color="off",
        )
    else:
        cols[1].metric("Latest result", "No results yet")
    cols[2].metric("Fees pending", money(fee["pending"]), delta=fee["status"], delta_color="off")

    counts = attendance_summary["counts"]
    if attendance_summary["marked"]:
        donut = px.pie(
            names=list(counts.keys()),
            values=list(counts.values()),
            hole=0.55,
            title="My attendance",
            color=list(counts.keys()),
            color_discrete_map=STATUS_COLORS,
        )
        donut.update_traces(textinfo="label+value")
        st.plotly_chart(style(donut), use_container_width=True)
    else:
        st.info("No attendance has been recorded for you yet.")

    _today_schedule(timetable.class_grid(int(info["class_id"])))
    _announcements_panel()


page_header("Dashboard", "📊", f"{SCHOOL_NAME} · {today():%A, %d %B %Y}")
if user["role"] == "admin":
    admin_dashboard()
elif user["role"] == "teacher":
    teacher_dashboard()
else:
    student_dashboard()
