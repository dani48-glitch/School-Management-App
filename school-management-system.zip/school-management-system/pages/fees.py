"""Fees: structure, payments, pending dues and printable receipts."""
from __future__ import annotations

from datetime import timedelta

import plotly.express as px
import streamlit as st

from services import academics, dashboard, fees, pdf, students
from utils import session
from utils.charts import STATUS_COLORS, style
from utils.clock import today
from utils.config import CURRENCY, PAYMENT_METHODS, SCHOOL_NAME
from utils.tables import changed_rows, export_buttons
from utils.ui import editor_key, flash, money, page_header, reset_editor, select_from
from utils.validators import ValidationError

user = session.require_role("admin", "student")
role = user["role"]

page_header("Fees", "💰", f"Amounts are in {CURRENCY}.")


def _receipt_download(payment_id: int, key: str, label: str = "🧾 Download receipt (PDF)") -> None:
    receipt = fees.get_receipt(payment_id)
    if receipt is None:
        st.warning("Receipt not found.")
        return
    st.download_button(
        label,
        data=pdf.receipt_pdf(receipt, SCHOOL_NAME, CURRENCY),
        file_name=f"{receipt['receipt_no']}.pdf",
        mime="application/pdf",
        key=key,
    )


# --------------------------------------------------------------------------
# Admin
# --------------------------------------------------------------------------
def _structure_tab() -> None:
    class_options = academics.class_options()
    if not class_options:
        st.info("Create a class first.")
        return
    class_id = select_from("Class", class_options, key="fee_class")

    with st.form("fee_line_form", clear_on_submit=True):
        col_a, col_b = st.columns([2, 1])
        fee_type = col_a.text_input("Fee type *", placeholder="Tuition", max_chars=60)
        amount = col_b.number_input("Amount *", min_value=1, value=1000, step=100)
        submitted = st.form_submit_button("Add / update fee line", type="primary")
    if submitted:
        try:
            fees.set_fee(class_id, fee_type, amount)
            reset_editor("fees")
            flash("success", "Fee line saved.")
            st.rerun()
        except ValidationError as exc:
            st.error(str(exc))

    table = fees.fee_structure(class_id)
    if table.empty:
        st.info("No fees set for this class yet.")
        return
    st.metric("Total per student", money(int(table["amount"].sum())))

    view = table.copy()
    view["delete"] = False
    edited = st.data_editor(
        view,
        key=editor_key("fees"),
        hide_index=True,
        use_container_width=True,
        num_rows="fixed",
        disabled=["class"],
        column_order=["class", "fee_type", "amount", "delete"],
        column_config={
            "class": "Class",
            "fee_type": st.column_config.TextColumn("Fee type", required=True, max_chars=60),
            "amount": st.column_config.NumberColumn("Amount", min_value=1, step=100, required=True),
            "delete": st.column_config.CheckboxColumn("Delete", default=False),
        },
    )
    export_buttons(table.drop(columns=["id", "class_id"]), "fee_structure", "fee_structure_export")

    to_delete = edited.loc[edited["delete"], "id"].astype(int).tolist()
    pending_changes = [
        change
        for change in changed_rows(view, edited, ["fee_type", "amount"])
        if change["id"] not in to_delete
    ]
    save_col, delete_col, _ = st.columns([1, 1.4, 3])
    if save_col.button("💾 Save changes", type="primary", disabled=not pending_changes,
                       key="fee_save"):
        try:
            for change in pending_changes:
                fees.update_fee(change["id"], change["fee_type"], change["amount"])
            reset_editor("fees")
            flash("success", "Fee structure updated.")
            st.rerun()
        except ValidationError as exc:
            st.error(str(exc))
    if to_delete:
        confirmed = st.checkbox("Yes, delete the selected fee lines", key="confirm_fee_delete")
        if delete_col.button("🗑️ Delete selected", disabled=not confirmed, key="fee_delete"):
            try:
                for fee_id in to_delete:
                    fees.delete_fee(fee_id)
                reset_editor("fees")
                flash("success", "Fee line(s) deleted.")
                st.rerun()
            except ValidationError as exc:
                st.error(str(exc))


def _collect_tab() -> None:
    class_options = academics.class_options()
    if not class_options:
        st.info("Create a class first.")
        return

    last_payment = st.session_state.get("last_payment_id")
    if last_payment:
        st.success("Last payment recorded. Its receipt is ready to download:")
        _receipt_download(last_payment, key="receipt_last")

    col_class, col_student = st.columns(2)
    class_id = select_from("Class", class_options, key="collect_class", container=col_class)
    student_id = select_from(
        "Student", students.student_options(class_id), key="collect_student",
        container=col_student,
    )
    if student_id is None:
        st.info("This class has no students yet.")
        return

    summary = fees.student_fee_summary(student_id)
    cols = st.columns(4)
    cols[0].metric("Total fee", money(summary["total"]))
    cols[1].metric("Paid", money(summary["paid"]))
    cols[2].metric("Pending", money(summary["pending"]))
    cols[3].metric("Status", summary["status"])

    if summary["total"] == 0:
        st.warning("No fee structure is set for this class (see the Fee structure tab).")
        return
    if summary["pending"] == 0:
        st.success("This student has no pending dues.")
        return

    with st.form("payment_form", clear_on_submit=True):
        col_a, col_b = st.columns(2)
        amount = col_a.number_input(
            f"Amount ({CURRENCY})",
            min_value=1,
            max_value=int(summary["pending"]),
            value=int(summary["pending"]),
            step=100,
        )
        method = col_b.selectbox("Payment method", PAYMENT_METHODS)
        paid_on = col_a.date_input("Payment date", value=today(), max_value=today())
        note = col_b.text_input("Note (optional)", max_chars=200)
        submitted = st.form_submit_button("Record payment", type="primary")
    if submitted:
        try:
            receipt = fees.record_payment(
                student_id, amount, method, paid_on, note, user["full_name"]
            )
            st.session_state["last_payment_id"] = receipt["payment_id"]
            st.rerun()
        except ValidationError as exc:
            st.error(str(exc))


def _dues_tab() -> None:
    class_id = select_from(
        "Class", academics.class_options(), key="dues_class", include_all=True,
        all_label="All classes",
    )
    table = fees.dues_table(class_id=class_id)
    if table.empty:
        st.info("No students found.")
        return

    statuses = sorted(table["status"].unique())
    chosen = st.multiselect("Status", statuses, default=statuses, key="dues_status")
    table = table[table["status"].isin(chosen)]

    cols = st.columns(3)
    cols[0].metric("Total fees", money(int(table["total_fee"].sum())))
    cols[1].metric("Collected", money(int(table["paid"].sum())))
    cols[2].metric("Pending", money(int(table["pending"].sum())))

    shown = table.drop(columns=["student_id"])
    st.dataframe(
        shown,
        hide_index=True,
        use_container_width=True,
        column_config={
            "roll_no": "Roll no.",
            "name": "Name",
            "total_fee": st.column_config.NumberColumn("Total fee", format="%d"),
            "paid": st.column_config.NumberColumn("Paid", format="%d"),
            "pending": st.column_config.NumberColumn("Pending", format="%d"),
        },
    )
    export_buttons(shown, "fee_dues", "dues_export")

    by_class = dashboard.fees_by_class()
    if not by_class.empty:
        fig = px.bar(
            by_class,
            x="class",
            y=["collected", "pending"],
            barmode="stack",
            title="Collected vs pending by class",
            color_discrete_map=STATUS_COLORS,
        )
        fig.update_xaxes(title=None)
        fig.update_yaxes(title=None)
        st.plotly_chart(style(fig), use_container_width=True)


def _payments_tab() -> None:
    col_class, col_from, col_to = st.columns([2, 1, 1])
    class_id = select_from(
        "Class", academics.class_options(), key="pay_class", include_all=True,
        all_label="All classes", container=col_class,
    )
    start = col_from.date_input("From", value=today() - timedelta(days=90), key="pay_from")
    end = col_to.date_input("To", value=today(), key="pay_to")
    if start > end:
        st.error("The start date must not be after the end date.")
        return

    table = fees.payments(class_id=class_id, start=start, end=end)
    if table.empty:
        st.info("No payments in this period.")
        return
    st.metric("Collected in period", money(int(table["amount"].sum())))
    shown = table.drop(columns=["id"])
    st.dataframe(shown, hide_index=True, use_container_width=True)
    export_buttons(shown, "fee_payments", "payments_export")

    st.subheader("Receipt")
    options = [(int(row.id), f"{row.receipt_no} - {row.student} ({money(row.amount)})")
               for row in table.itertuples()]
    payment_id = select_from("Payment", options, key="receipt_select")
    if payment_id is not None:
        _receipt_download(payment_id, key="receipt_selected")
        with st.expander("🗑️ Delete this payment"):
            st.caption("Only for correcting a mistaken entry. The pending balance goes back up.")
            confirmed = st.checkbox("Yes, delete this payment", key="confirm_delete_payment")
            if st.button("Delete payment", disabled=not confirmed):
                try:
                    fees.delete_payment(payment_id)
                    st.session_state.pop("last_payment_id", None)
                    flash("success", "Payment deleted.")
                    st.rerun()
                except ValidationError as exc:
                    st.error(str(exc))


# --------------------------------------------------------------------------
# Student / parent
# --------------------------------------------------------------------------
def _my_fees() -> None:
    student_id = user.get("student_id")
    info = students.get_student(student_id) if student_id else None
    if info is None:
        st.warning("Your account is not linked to a student record. Ask the administrator.")
        return
    summary = fees.student_fee_summary(student_id)
    cols = st.columns(4)
    cols[0].metric("Total fee", money(summary["total"]))
    cols[1].metric("Paid", money(summary["paid"]))
    cols[2].metric("Pending", money(summary["pending"]))
    cols[3].metric("Status", summary["status"])

    st.subheader("Fee structure")
    structure = fees.fee_structure(int(info["class_id"]))[["fee_type", "amount"]]
    if structure.empty:
        st.info("No fees have been set for your class yet.")
    else:
        st.dataframe(structure, hide_index=True, use_container_width=True)
        export_buttons(structure, "my_fee_structure", "my_structure_export")

    st.subheader("Payments")
    table = fees.payments(student_id=student_id)
    if table.empty:
        st.info("No payments recorded yet.")
        return
    shown = table[["receipt_no", "paid_on", "amount", "method", "note"]]
    st.dataframe(shown, hide_index=True, use_container_width=True)
    export_buttons(shown, "my_payments", "my_payments_export")
    options = [
        (int(row.id), f"{row.receipt_no} - {money(row.amount)}") for row in table.itertuples()
    ]
    payment_id = select_from("Receipt", options, key="my_receipt")
    if payment_id is not None:
        _receipt_download(payment_id, key="my_receipt_download")


if role == "student":
    _my_fees()
else:
    structure_tab, collect_tab, dues_tab, payments_tab = st.tabs(
        ["🧮 Fee structure", "💳 Collect payment", "⏳ Pending dues", "🧾 Payments & receipts"]
    )
    with structure_tab:
        _structure_tab()
    with collect_tab:
        _collect_tab()
    with dues_tab:
        _dues_tab()
    with payments_tab:
        _payments_tab()
