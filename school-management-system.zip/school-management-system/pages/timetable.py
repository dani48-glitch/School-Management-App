"""Weekly timetable: everyone can view, the administrator edits."""
from __future__ import annotations

import streamlit as st

from services import academics, students, teachers, timetable
from utils import session
from utils.clock import today
from utils.config import DAYS, PERIODS
from utils.tables import export_buttons
from utils.ui import flash, page_header, select_from
from utils.validators import ValidationError

user = session.require_role("admin", "teacher", "student")
role = user["role"]

page_header("Timetable", "⏰", "Weekly schedule by class.")


def _show_grid(grid, filename: str, key: str) -> None:
    st.dataframe(grid, use_container_width=True)
    export_buttons(grid.rename_axis("period").reset_index(), filename, key)


def _view_class(class_id: int, key: str) -> None:
    grid = timetable.class_grid(class_id)
    if (grid == "").all().all():
        st.info("No timetable has been set for this class yet.")
        return
    _show_grid(grid, "class_timetable", key)


def _edit_class(class_id: int) -> None:
    subject_options = academics.class_subject_options(class_id)
    if not subject_options:
        st.info("Assign subjects to this class first (Classes & Subjects page).")
        return
    assigned = {
        int(row.subject_id): (None if row.teacher_id is None or row.teacher_id != row.teacher_id
                              else int(row.teacher_id))
        for row in academics.class_subject_table(class_id=class_id).itertuples()
    }

    col_day, col_period = st.columns(2)
    day = col_day.selectbox("Day", range(len(DAYS)), format_func=lambda i: DAYS[i], key="tt_day")
    period = col_period.selectbox(
        "Period", list(PERIODS), format_func=timetable.period_label, key="tt_period"
    )
    subject_id = select_from("Subject", subject_options, key="tt_subject")

    teacher_ids = [None] + [teacher_pk for teacher_pk, _ in teachers.teacher_options()]
    names = dict(teachers.teacher_options())
    default_teacher = assigned.get(subject_id)
    teacher_id = st.selectbox(
        "Teacher",
        teacher_ids,
        index=teacher_ids.index(default_teacher) if default_teacher in teacher_ids else 0,
        format_func=lambda value: "(none)" if value is None else names[value],
        key=f"tt_teacher_{class_id}_{subject_id}",
    )
    room = st.text_input("Room (optional)", max_chars=20, key=f"tt_room_{class_id}")

    col_save, col_clear, _ = st.columns([1, 1, 3])
    if col_save.button("💾 Save slot", type="primary"):
        try:
            timetable.save_entry(class_id, day, period, subject_id, teacher_id, room)
            flash("success", f"{DAYS[day]}, period {period} saved.")
            st.rerun()
        except ValidationError as exc:
            st.error(str(exc))
    if col_clear.button("🧹 Clear slot"):
        try:
            timetable.delete_entry(class_id, day, period)
            flash("success", f"{DAYS[day]}, period {period} cleared.")
            st.rerun()
        except ValidationError as exc:
            st.error(str(exc))


def _today_panel(grid) -> None:
    weekday = today().weekday()
    if weekday >= len(DAYS):
        return
    schedule = timetable.day_schedule(grid, weekday)
    schedule = schedule[schedule["lesson"] != ""]
    if not schedule.empty:
        st.subheader(f"Today - {DAYS[weekday]}")
        st.dataframe(schedule, hide_index=True, use_container_width=True)


if role == "student":
    info = students.get_student(user["student_id"]) if user.get("student_id") else None
    if info is None:
        st.warning("Your account is not linked to a student record. Ask the administrator.")
        st.stop()
    st.markdown(f"**{info['class']}**")
    my_grid = timetable.class_grid(int(info["class_id"]))
    _today_panel(my_grid)
    _view_class(int(info["class_id"]), key="student_tt")

elif role == "teacher":
    teacher_id = user.get("teacher_id")
    mode = st.radio("Show", ["My schedule", "A class timetable"], horizontal=True, key="tt_mode")
    if mode == "My schedule":
        if not teacher_id:
            st.warning("Your account is not linked to a teacher profile.")
            st.stop()
        mine = timetable.teacher_grid(teacher_id)
        if (mine == "").all().all():
            st.info("You have no timetable slots yet.")
        else:
            _today_panel(mine)
            _show_grid(mine, "my_timetable", "teacher_tt")
    else:
        class_id = select_from("Class", academics.class_options(), key="tt_class_view")
        if class_id is not None:
            _view_class(class_id, key="teacher_class_tt")

else:
    class_id = select_from("Class", academics.class_options(), key="tt_class_admin")
    if class_id is None:
        st.info("Create a class first.")
        st.stop()
    view_tab, edit_tab = st.tabs(["👁️ View", "✏️ Edit"])
    with view_tab:
        _view_class(class_id, key="admin_tt")
    with edit_tab:
        _edit_class(class_id)
