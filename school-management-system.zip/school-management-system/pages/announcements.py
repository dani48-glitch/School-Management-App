"""Notice board: everyone reads, the administrator posts and removes notices."""
from __future__ import annotations

import streamlit as st

from services import announcements
from utils import session
from utils.ui import flash, page_header
from utils.validators import ValidationError

user = session.require_role("admin", "teacher", "student")
is_admin = user["role"] == "admin"

page_header("Announcements", "📢", "Notices from the school office.")

if is_admin:
    with st.expander("➕ Post a new announcement"):
        with st.form("announcement_form", clear_on_submit=True):
            title = st.text_input("Title", max_chars=150)
            body = st.text_area("Message", max_chars=5000, height=140)
            posted = st.form_submit_button("Post announcement", type="primary")
        if posted:
            try:
                announcements.add_announcement(title, body, user["full_name"])
                flash("success", "Announcement posted.")
                st.rerun()
            except ValidationError as exc:
                st.error(str(exc))

items = announcements.list_announcements()
if not items:
    st.info("There are no announcements yet.")

for item in items:
    with st.container(border=True):
        st.markdown(f"### {item['title']}")
        st.caption(f"Posted by {item['posted_by']} on {item['created_at']:%d %b %Y, %H:%M} UTC")
        st.markdown(item["body"])
        if is_admin and st.button("🗑️ Delete", key=f"delete_announcement_{item['id']}"):
            try:
                announcements.delete_announcement(item["id"])
                flash("success", "Announcement deleted.")
                st.rerun()
            except ValidationError as exc:
                st.error(str(exc))
