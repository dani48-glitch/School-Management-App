"""My account: profile details and password change (all roles)."""
from __future__ import annotations

import streamlit as st

from services import auth, students, teachers
from utils import session
from utils.ui import flash, page_header
from utils.validators import ValidationError

user = session.require_role("admin", "teacher", "student")

page_header("My Account", "⚙️")

st.markdown(f"**Name:** {user['full_name']}")
st.markdown(f"**Username:** `{user['username']}`")
st.markdown(f"**Role:** {user['role'].title()}")

if user["role"] == "student" and user.get("student_id"):
    info = students.get_student(user["student_id"])
    if info:
        st.markdown(f"**Class:** {info['class']} · **Roll no.:** {info['roll_no']}")
        st.markdown(f"**Guardian:** {info['guardian_name']} · **Phone:** {info['phone']}")
elif user["role"] == "teacher" and user.get("teacher_id"):
    profile = teachers.get_teacher(user["teacher_id"])
    if profile:
        st.markdown(f"**Subjects:** {profile['subjects'] or '-'}")
        st.markdown(f"**Classes:** {profile['classes'] or '-'}")

st.divider()
st.subheader("Change password")
with st.form("change_password_form", clear_on_submit=True):
    current = st.text_input("Current password", type="password", autocomplete="current-password")
    new = st.text_input("New password", type="password", autocomplete="new-password")
    confirm = st.text_input("Confirm new password", type="password", autocomplete="new-password")
    submitted = st.form_submit_button("Update password", type="primary")
st.caption("At least 8 characters with a letter and a digit.")

if submitted:
    try:
        auth.change_password(user["id"], current, new, confirm)
        flash("success", "Your password was updated.")
        st.rerun()
    except ValidationError as exc:
        st.error(str(exc))
