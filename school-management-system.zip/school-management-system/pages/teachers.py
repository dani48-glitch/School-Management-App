"""Teacher profiles, with the subjects and classes each teacher is assigned to (admin only)."""
from __future__ import annotations

import streamlit as st

from services import teachers
from utils import session
from utils.tables import changed_rows, export_buttons
from utils.ui import editor_key, flash, page_header, reset_editor, select_from
from utils.validators import ValidationError

user = session.require_role("admin")

page_header("Teachers", "👩‍🏫", "Profiles, subjects and class assignments.")

EDITABLE = ["name", "email", "phone", "qualification", "joined_on"]


def _list_tab() -> None:
    search = st.text_input("🔎 Search", placeholder="Name, email or phone", key="teacher_search")
    table = teachers.list_teachers(search)
    st.caption(f"{len(table)} teacher(s)")
    if table.empty:
        st.info("No teachers found.")
        return

    export_buttons(table.drop(columns=["id"]), "teachers", "teachers_export")
    st.caption(
        "Double-click a cell to edit. Subjects and classes come from **Classes & Subjects** "
        "and cannot be edited here."
    )
    view = table.copy()
    view["delete"] = False
    edited = st.data_editor(
        view,
        key=editor_key("teachers"),
        hide_index=True,
        use_container_width=True,
        num_rows="fixed",
        disabled=["subjects", "classes"],
        column_order=EDITABLE + ["subjects", "classes", "delete"],
        column_config={
            "name": st.column_config.TextColumn("Name", required=True, max_chars=100),
            "email": st.column_config.TextColumn("Email", max_chars=120),
            "phone": st.column_config.TextColumn("Phone", max_chars=30),
            "qualification": st.column_config.TextColumn("Qualification", max_chars=120),
            "joined_on": st.column_config.DateColumn("Joined", format="YYYY-MM-DD"),
            "subjects": st.column_config.TextColumn("Subjects"),
            "classes": st.column_config.TextColumn("Classes"),
            "delete": st.column_config.CheckboxColumn("Delete", default=False),
        },
    )

    to_delete = edited.loc[edited["delete"], "id"].astype(int).tolist()
    pending_changes = [
        change for change in changed_rows(view, edited, EDITABLE) if change["id"] not in to_delete
    ]

    save_col, delete_col, _ = st.columns([1, 1.4, 3])
    if save_col.button("💾 Save changes", type="primary", disabled=not pending_changes):
        errors, saved = [], 0
        for change in pending_changes:
            row_id = change.pop("id")
            try:
                teachers.update_teacher(row_id, **change)
                saved += 1
            except ValidationError as exc:
                errors.append(f"{change.get('name') or 'Teacher'}: {exc}")
        if errors:
            st.error("Some rows could not be saved:\n\n- " + "\n- ".join(errors))
            if saved:
                st.success(f"{saved} row(s) saved.")
        else:
            reset_editor("teachers")
            flash("success", f"{saved} teacher record(s) updated.")
            st.rerun()

    if to_delete:
        st.warning(
            f"{len(to_delete)} teacher(s) selected. Their login accounts are removed and their "
            "classes and timetable slots become unassigned."
        )
        confirmed = st.checkbox("Yes, permanently delete the selected teachers", key="confirm_del")
        if delete_col.button("🗑️ Delete selected", disabled=not confirmed):
            try:
                for teacher_id in to_delete:
                    teachers.delete_teacher(teacher_id)
                reset_editor("teachers")
                flash("success", f"{len(to_delete)} teacher(s) deleted.")
                st.rerun()
            except ValidationError as exc:
                st.error(str(exc))


def _add_tab() -> None:
    with st.form("add_teacher_form", clear_on_submit=True):
        col_a, col_b = st.columns(2)
        name = col_a.text_input("Full name *", max_chars=100)
        email = col_b.text_input("Email", max_chars=120)
        phone = col_a.text_input("Phone", max_chars=30)
        qualification = col_b.text_input("Qualification", max_chars=120)
        joined_on = col_a.date_input("Joining date", value=None)
        submitted = st.form_submit_button("Add teacher", type="primary")
    if submitted:
        try:
            teachers.add_teacher(name, email, phone, qualification, joined_on)
            flash("success", f"{name.strip()} was added. Assign classes under Classes & Subjects.")
            st.rerun()
        except ValidationError as exc:
            st.error(str(exc))
    st.caption("To give a teacher a login, open **User Accounts** and create a teacher account.")


def _assignments_tab() -> None:
    options = teachers.teacher_options()
    if not options:
        st.info("Add a teacher first.")
        return
    teacher_id = select_from("Teacher", options, key="assignments_teacher")
    if teacher_id is None:
        return
    profile = teachers.get_teacher(teacher_id)
    if profile:
        qualification = profile["qualification"] or "No qualification set"
        st.markdown(f"**{profile['name']}** · {qualification}")
        st.caption(f"{profile['email'] or 'No email'} · {profile['phone'] or 'No phone'}")
    table = teachers.teacher_assignments(teacher_id)
    if table.empty:
        st.info("This teacher is not assigned to any class yet.")
    else:
        shown = table.drop(columns=["class_id"])
        st.dataframe(shown, hide_index=True, use_container_width=True)
        export_buttons(shown, "teacher_assignments", "assignments_export")


list_tab, add_tab, assign_tab = st.tabs(["📋 Teacher list", "➕ Add teacher", "📚 Assignments"])
with list_tab:
    _list_tab()
with add_tab:
    _add_tab()
with assign_tab:
    _assignments_tab()
